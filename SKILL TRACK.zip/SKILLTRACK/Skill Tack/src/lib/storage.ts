
// Types for user data
export interface User {
  id: string;
  email: string;
  name: string;
  password: string; // In a real app, we would never store this in plain text
  selectedDomain?: string;
  domainLevel?: 'Beginner' | 'Intermediate' | 'Advanced' | 'Pro';
  testScores: {
    [domain: string]: number;
  };
  appliedJobs: {
    [domain: string]: Job[];
  };
  resumeAnalysis?: {
    score: number;
    suggestions: string[];
  };
}

export interface Job {
  id: string;
  company: string;
  role: string;
  description: string;
  domain: string;
  status: 'Pending' | 'Shortlisted' | 'Rejected';
}

// Storage keys
const USERS_KEY = 'skilltrack_users';
const CURRENT_USER_KEY = 'skilltrack_current_user';

// Local storage helper functions
export const getUsers = (): User[] => {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
};

export const saveUsers = (users: User[]) => {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const getCurrentUser = (): User | null => {
  const user = localStorage.getItem(CURRENT_USER_KEY);
  return user ? JSON.parse(user) : null;
};

export const setCurrentUser = (user: User | null) => {
  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
};

// Authentication functions
export const registerUser = (email: string, password: string, name: string): User => {
  const users = getUsers();
  
  // Check if user already exists
  if (users.some(u => u.email === email)) {
    throw new Error('User already exists');
  }
  
  // Create a new user
  const newUser: User = {
    id: crypto.randomUUID(),
    email,
    name,
    password,
    testScores: {},
    appliedJobs: {},
  };
  
  // Save the new user
  users.push(newUser);
  saveUsers(users);
  setCurrentUser(newUser);
  
  return newUser;
};

export const loginUser = (email: string, password: string): User => {
  const users = getUsers();
  const user = users.find(u => u.email === email && u.password === password);
  
  if (!user) {
    throw new Error('Invalid email or password');
  }
  
  setCurrentUser(user);
  return user;
};

export const logoutUser = () => {
  setCurrentUser(null);
};

// Domain related functions
export const updateUserDomain = (domain: string) => {
  const user = getCurrentUser();
  if (!user) return;
  
  user.selectedDomain = domain;
  
  // Update in local storage
  const users = getUsers();
  const userIndex = users.findIndex(u => u.id === user.id);
  if (userIndex >= 0) {
    users[userIndex] = user;
    saveUsers(users);
  }
  
  setCurrentUser(user);
};

export const updateDomainTestScore = (domain: string, score: number) => {
  const user = getCurrentUser();
  if (!user) return;
  
  // Set the test score
  user.testScores = {
    ...user.testScores,
    [domain]: score
  };
  
  // Set the domain level
  let level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Pro';
  if (score <= 45) {
    level = 'Beginner';
  } else if (score <= 60) {
    level = 'Intermediate';
  } else if (score <= 75) {
    level = 'Advanced';
  } else {
    level = 'Pro';
  }
  
  user.domainLevel = level;
  
  // Update in local storage
  const users = getUsers();
  const userIndex = users.findIndex(u => u.id === user.id);
  if (userIndex >= 0) {
    users[userIndex] = user;
    saveUsers(users);
  }
  
  setCurrentUser(user);
};

// Job application functions
export const applyToJob = (job: Job) => {
  const user = getCurrentUser();
  if (!user) return;
  
  // Initialize the domain if it doesn't exist
  if (!user.appliedJobs[job.domain]) {
    user.appliedJobs[job.domain] = [];
  }
  
  // Check if already applied
  const alreadyApplied = user.appliedJobs[job.domain].some(j => j.id === job.id);
  if (alreadyApplied) {
    throw new Error('Already applied to this job');
  }
  
  // Check if max applications reached
  if (user.appliedJobs[job.domain].length >= 5) {
    throw new Error('Maximum job applications reached for this domain');
  }
  
  // Add the job to applied jobs
  user.appliedJobs[job.domain].push({ ...job, status: 'Pending' });
  
  // Update in local storage
  const users = getUsers();
  const userIndex = users.findIndex(u => u.id === user.id);
  if (userIndex >= 0) {
    users[userIndex] = user;
    saveUsers(users);
  }
  
  setCurrentUser(user);
};

// Resume analysis functions
export const saveResumeAnalysis = (score: number, suggestions: string[]) => {
  const user = getCurrentUser();
  if (!user) return;
  
  user.resumeAnalysis = { score, suggestions };
  
  // Update in local storage
  const users = getUsers();
  const userIndex = users.findIndex(u => u.id === user.id);
  if (userIndex >= 0) {
    users[userIndex] = user;
    saveUsers(users);
  }
  
  setCurrentUser(user);
};
