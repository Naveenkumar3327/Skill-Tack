
import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ChevronLeft, ChevronRight, Linkedin } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  company: string;
  text: string;
  image: string;
  linkedin?: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Ravi Kumar',
    role: 'Frontend Developer',
    company: 'Microsoft',
    text: 'SkillTrack helped me identify my passion for web development and guided me through the roadmap to success. Within 6 months, I landed my dream job!',
    image: 'https://i.pravatar.cc/150?img=12',
    linkedin: 'https://linkedin.com/',
  },
  {
    id: 2,
    name: 'Priya Sharma',
    role: 'Data Scientist',
    company: 'Amazon',
    text: 'The domain test was eye-opening. I was confused between AI and Data Science, but SkillTrack helped me find my perfect fit and now I\'m thriving in my career.',
    image: 'https://i.pravatar.cc/150?img=26',
    linkedin: 'https://linkedin.com/',
  },
  {
    id: 3,
    name: 'Arjun Reddy',
    role: 'Cybersecurity Analyst',
    company: 'Deloitte',
    text: 'The daily tests and resume analyzer were game-changers for me. I improved my skills consistently and optimized my resume, which led to multiple job offers.',
    image: 'https://i.pravatar.cc/150?img=33',
    linkedin: 'https://linkedin.com/',
  },
  {
    id: 4,
    name: 'Neha Gupta',
    role: 'UI/UX Designer',
    company: 'Google',
    text: 'I was stuck in a career plateau until I found SkillTrack. Their roadmap and course recommendations were exactly what I needed to level up my skills.',
    image: 'https://i.pravatar.cc/150?img=48',
    linkedin: 'https://linkedin.com/',
  },
];

export function TestimonialsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const autoPlayRef = useRef<NodeJS.Timeout | null>(null);
  
  const goToNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };
  
  const goToPrev = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };
  
  const startAutoPlay = () => {
    if (autoPlayRef.current) clearInterval(autoPlayRef.current);
    autoPlayRef.current = setInterval(goToNext, 5000);
  };
  
  const stopAutoPlay = () => {
    if (autoPlayRef.current) {
      clearInterval(autoPlayRef.current);
      autoPlayRef.current = null;
    }
  };
  
  // Handle auto-play
  useEffect(() => {
    if (isAutoPlaying) {
      startAutoPlay();
    } else {
      stopAutoPlay();
    }
    
    return () => stopAutoPlay();
  }, [isAutoPlaying, testimonials.length]);
  
  const handleMouseEnter = () => setIsAutoPlaying(false);
  const handleMouseLeave = () => setIsAutoPlaying(true);
  
  return (
    <div 
      className="relative p-4 max-w-4xl mx-auto" 
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <div className="overflow-hidden">
        <div 
          className="flex transition-transform duration-500 ease-in-out" 
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="flex-shrink-0 w-full shadow-sm">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-start md:items-center gap-4 mb-4">
                  <Avatar className="h-16 w-16 border-2 border-brand-purple">
                    <AvatarImage src={testimonial.image} alt={testimonial.name} />
                    <AvatarFallback className="bg-brand-purple text-white">
                      {testimonial.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-semibold text-lg">{testimonial.name}</h4>
                        <p className="text-sm text-gray-600">
                          {testimonial.role} at {testimonial.company}
                        </p>
                      </div>
                      {testimonial.linkedin && (
                        <a 
                          href={testimonial.linkedin}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-brand-blue hover:text-brand-purple transition-colors"
                        >
                          <Linkedin className="h-5 w-5" />
                        </a>
                      )}
                    </div>
                    <p className="mt-2 text-gray-700 italic">"{testimonial.text}"</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      
      <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 flex justify-between px-2 md:px-4">
        <Button
          onClick={goToPrev}
          variant="outline"
          size="icon"
          className="bg-white/80 backdrop-blur-sm hover:bg-white"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Button
          onClick={goToNext}
          variant="outline"
          size="icon"
          className="bg-white/80 backdrop-blur-sm hover:bg-white"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
      
      <div className="flex justify-center mt-4 gap-1">
        {testimonials.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-2.5 h-2.5 rounded-full transition-all ${
              index === currentIndex 
                ? 'bg-brand-purple w-5'
                : 'bg-gray-300 hover:bg-gray-400'
            }`}
            aria-label={`Go to testimonial ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
