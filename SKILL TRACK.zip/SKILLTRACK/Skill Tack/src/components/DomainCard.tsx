
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Domain } from '@/data/domainData';
import { cn } from '@/lib/utils';

interface DomainCardProps {
  domain: Domain;
  variant?: 'default' | 'compact';
  className?: string;
  selected?: boolean;
  onSelect?: () => void;
}

const DomainCard: React.FC<DomainCardProps> = ({
  domain,
  variant = 'default',
  className,
  selected = false,
  onSelect
}) => {
  const navigate = useNavigate();
  
  const handleTestClick = () => {
    navigate(`/domain-test/${domain.id}`);
  };
  
  const handleSelect = () => {
    if (onSelect) {
      onSelect();
    }
  };
  
  if (variant === 'compact') {
    return (
      <Card 
        className={cn(
          'transition-all duration-200 cursor-pointer hover:shadow-md',
          selected && 'ring-2 ring-brand-blue',
          className
        )}
        onClick={handleSelect}
      >
        <CardHeader className="p-4">
          <div className="flex items-center gap-2">
            <div className="text-3xl">{domain.icon}</div>
            <h3 className="font-medium">{domain.name}</h3>
          </div>
        </CardHeader>
        <CardFooter className="p-4 pt-0 flex justify-between">
          <Badge variant="outline">{domain.avgSalary}</Badge>
        </CardFooter>
      </Card>
    );
  }
  
  return (
    <Card className={cn('h-full overflow-hidden transition-all hover:shadow-lg', className)}>
      <CardHeader className="p-6 bg-gradient-to-r from-brand-blue to-brand-purple">
        <div className="flex items-center gap-3">
          <div className="text-4xl bg-white rounded-full p-2 w-12 h-12 flex items-center justify-center">
            {domain.icon}
          </div>
          <h3 className="text-xl font-semibold text-white">{domain.name}</h3>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <p className="text-gray-600 mb-4">{domain.description}</p>
        <div className="space-y-3">
          <div>
            <p className="text-sm font-medium text-gray-700">Average Salary (India)</p>
            <p className="text-brand-blue font-semibold">{domain.avgSalary}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-700">Top Companies</p>
            <div className="flex flex-wrap gap-1 mt-1">
              {domain.topCompanies.slice(0, 3).map((company) => (
                <Badge key={company} variant="secondary" className="mr-1">
                  {company}
                </Badge>
              ))}
              {domain.topCompanies.length > 3 && (
                <Badge variant="outline">+{domain.topCompanies.length - 3} more</Badge>
              )}
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-700">Latest Technologies</p>
            <div className="flex flex-wrap gap-1 mt-1">
              {domain.latestTech.slice(0, 3).map((tech) => (
                <Badge key={tech} variant="outline" className="mr-1">
                  {tech}
                </Badge>
              ))}
              {domain.latestTech.length > 3 && (
                <Badge variant="outline">+{domain.latestTech.length - 3} more</Badge>
              )}
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-6 pt-0">
        <Button 
          onClick={handleTestClick} 
          className="w-full bg-gradient-to-r from-brand-blue to-brand-purple hover:opacity-90"
        >
          Choose Domain
        </Button>
      </CardFooter>
    </Card>
  );
};

export default DomainCard;
