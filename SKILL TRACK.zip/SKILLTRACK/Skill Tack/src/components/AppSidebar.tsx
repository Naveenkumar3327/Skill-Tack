
import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  Home,
  Book,
  FileText,
  User,
  FileSearch,
  BriefcaseIcon,
  LayoutDashboard,
  BookOpenText,
  FileCheck,
  Menu,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useIsMobile } from '@/hooks/use-mobile';

const navigation = [
  { name: 'Home', href: '/home', icon: Home },
  { name: 'Domains', href: '/domains', icon: LayoutDashboard },
  { name: 'Study Buddy', href: '/study', icon: Book },
  { name: 'Daily Test', href: '/daily-test', icon: FileText },
  { name: 'Roadmap', href: '/roadmap', icon: FileSearch },
  { name: 'Job Offers', href: '/jobs', icon: BriefcaseIcon },
  { name: 'My Jobs', href: '/my-jobs', icon: BookOpenText },
  { name: 'Resume Analyzer', href: '/resume', icon: FileCheck },
  { name: 'Profile', href: '/profile', icon: User },
];

export function AppSidebar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const isMobile = useIsMobile();
  
  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };
  
  const closeSidebar = () => {
    if (isMobile) {
      setIsOpen(false);
    }
  };

  return (
    <>
      {/* Mobile menu button */}
      <div className="fixed top-4 left-4 z-50 md:hidden">
        <Button variant="outline" size="icon" onClick={toggleSidebar} className="bg-white">
          {isOpen ? <X size={20} /> : <Menu size={20} />}
        </Button>
      </div>
      
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 bg-white shadow-lg transition-transform duration-300 ease-in-out",
          isMobile && !isOpen ? "-translate-x-full" : "translate-x-0"
        )}
      >
        <div className="flex h-full flex-col">
          {/* Logo */}
          <div className="flex h-16 items-center justify-center border-b">
            <Link to="/" className="flex items-center">
              <span className="text-2xl font-bold bg-gradient-to-r from-brand-blue to-brand-purple bg-clip-text text-transparent">SkillTrack</span>
            </Link>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-2 py-4 overflow-y-auto">
            <ul className="space-y-1">
              {navigation.map((item) => (
                <li key={item.name}>
                  <Link
                    to={item.href}
                    onClick={closeSidebar}
                    className={cn(
                      "flex items-center px-4 py-2 text-sm rounded-md transition-colors",
                      location.pathname === item.href
                        ? "bg-brand-blue bg-opacity-10 text-brand-blue font-medium"
                        : "text-gray-600 hover:bg-gray-100"
                    )}
                  >
                    <item.icon className="mr-3 h-5 w-5 flex-shrink-0" />
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Footer */}
          <div className="border-t p-4">
            <p className="text-xs text-gray-500 text-center">
              © 2024 SkillTrack
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}
