
export interface Domain {
  id: string;
  name: string;
  description: string;
  avgSalary: string;
  topCompanies: string[];
  latestTech: string[];
  icon: string;
}

export interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface Course {
  id: string;
  title: string;
  provider: string;
  url: string;
  image: string;
  price: string;
  rating: number;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';
}

export interface Certification {
  id: string;
  title: string;
  provider: string;
  url: string;
  image: string;
  price: string;
  duration: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  difficulty: 'Easy' | 'Intermediate' | 'Hard';
  url: string;
}

export interface Job {
  id: string;
  company: string;
  logo: string;
  role: string;
  location: string;
  salary: string;
  description: string;
  requirements: string[];
  url: string;
}

// Define our domains
export const domains: Domain[] = [
  {
    id: 'web-dev',
    name: 'Web Development',
    description: 'Create and maintain websites and web applications using technologies like HTML, CSS, JavaScript, and various frameworks.',
    avgSalary: '₹5,00,000 - ₹18,00,000',
    topCompanies: ['Google', 'Microsoft', 'Amazon', 'Meta', 'Infosys'],
    latestTech: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'GraphQL'],
    icon: '🌐',
  },
  {
    id: 'data-science',
    name: 'Data Science',
    description: 'Analyze and interpret complex data to help organizations make better business decisions.',
    avgSalary: '₹6,00,000 - ₹20,00,000',
    topCompanies: ['Amazon', 'Microsoft', 'IBM', 'Accenture', 'TCS'],
    latestTech: ['Python', 'TensorFlow', 'PyTorch', 'Pandas', 'Tableau'],
    icon: '📊',
  },
  {
    id: 'ai-ml',
    name: 'AI/ML',
    description: 'Build systems and applications that can learn from data and make decisions with minimal human intervention.',
    avgSalary: '₹8,00,000 - ₹25,00,000',
    topCompanies: ['Google', 'Amazon', 'Microsoft', 'IBM', 'Nvidia'],
    latestTech: ['TensorFlow', 'PyTorch', 'Keras', 'Scikit-learn', 'Hugging Face'],
    icon: '🤖',
  },
  {
    id: 'cybersecurity',
    name: 'Cybersecurity',
    description: 'Protect systems, networks, and programs from digital attacks.',
    avgSalary: '₹6,00,000 - ₹24,00,000',
    topCompanies: ['Microsoft', 'Cisco', 'IBM', 'Deloitte', 'Infosys'],
    latestTech: ['Threat Intelligence', 'SIEM', 'Zero Trust', 'Cloud Security', 'DevSecOps'],
    icon: '🔒',
  },
  {
    id: 'cloud-computing',
    name: 'Cloud Computing',
    description: 'Deliver computing services over the internet ("the cloud") to offer faster innovation and flexible resources.',
    avgSalary: '₹7,00,000 - ₹22,00,000',
    topCompanies: ['Amazon', 'Microsoft', 'Google', 'IBM', 'Oracle'],
    latestTech: ['AWS', 'Azure', 'Google Cloud', 'Docker', 'Kubernetes'],
    icon: '☁️',
  },
  {
    id: 'mobile-dev',
    name: 'Mobile App Development',
    description: 'Create applications that run on mobile devices.',
    avgSalary: '₹5,00,000 - ₹18,00,000',
    topCompanies: ['Google', 'Apple', 'Microsoft', 'Meta', 'Wipro'],
    latestTech: ['Flutter', 'React Native', 'Kotlin', 'Swift', 'Jetpack Compose'],
    icon: '📱',
  },
  {
    id: 'game-dev',
    name: 'Game Development',
    description: 'Design, develop, and publish video games for various platforms.',
    avgSalary: '₹5,00,000 - ₹20,00,000',
    topCompanies: ['Ubisoft', 'EA', 'Activision Blizzard', 'Rockstar Games', 'Nazara'],
    latestTech: ['Unity', 'Unreal Engine', 'C#', 'C++', 'WebGL'],
    icon: '🎮',
  },
  {
    id: 'devops',
    name: 'DevOps',
    description: 'Combine software development and IT operations to shorten the system development life cycle.',
    avgSalary: '₹7,00,000 - ₹24,00,000',
    topCompanies: ['Amazon', 'Google', 'Microsoft', 'IBM', 'TCS'],
    latestTech: ['Docker', 'Kubernetes', 'Jenkins', 'Terraform', 'GitLab CI/CD'],
    icon: '⚙️',
  },
  {
    id: 'blockchain',
    name: 'Blockchain',
    description: 'Build decentralized applications and smart contracts on blockchain platforms.',
    avgSalary: '₹6,00,000 - ₹24,00,000',
    topCompanies: ['ConsenSys', 'Polygon', 'Binance', 'Infosys', 'TCS'],
    latestTech: ['Ethereum', 'Solidity', 'Web3.js', 'Hyperledger', 'Polkadot'],
    icon: '⛓️',
  },
  {
    id: 'ui-ux',
    name: 'UI/UX Design',
    description: 'Create user-friendly interfaces and experiences for digital products and services.',
    avgSalary: '₹5,00,000 - ₹18,00,000',
    topCompanies: ['Google', 'Microsoft', 'Apple', 'Adobe', 'Infosys'],
    latestTech: ['Figma', 'Adobe XD', 'Sketch', 'Framer', 'Webflow'],
    icon: '🎨',
  },
];

// Sample domain questions - Web Development
export const domainQuestions: Record<string, Question[]> = {
  'web-dev': [
    {
      id: 'web-1',
      question: 'What does HTML stand for?',
      options: [
        'Hyper Text Markup Language',
        'High Tech Modern Language',
        'Hyper Transfer Markup Language',
        'Home Tool Markup Language'
      ],
      correctAnswer: 0
    },
    {
      id: 'web-2',
      question: 'Which of the following is used to style web pages?',
      options: ['HTML', 'JavaScript', 'CSS', 'XML'],
      correctAnswer: 2
    },
    {
      id: 'web-3',
      question: 'Which JavaScript framework is developed by Facebook?',
      options: ['Angular', 'Vue', 'React', 'Svelte'],
      correctAnswer: 2
    },
    {
      id: 'web-4',
      question: 'What does API stand for in web development?',
      options: [
        'Application Programming Interface',
        'Advanced Programming Integration',
        'Automated Program Interaction',
        'Application Process Integration'
      ],
      correctAnswer: 0
    },
    {
      id: 'web-5',
      question: 'Which of these is a CSS preprocessor?',
      options: ['jQuery', 'SASS', 'Babel', 'Webpack'],
      correctAnswer: 1
    },
    {
      id: 'web-6',
      question: 'What is the current version of ECMAScript (JavaScript)?',
      options: ['ES5', 'ES6', 'ES2022', 'ES2023'],
      correctAnswer: 3
    },
    {
      id: 'web-7',
      question: 'Which HTTP method is used to update a resource?',
      options: ['GET', 'POST', 'PUT', 'DELETE'],
      correctAnswer: 2
    },
    {
      id: 'web-8',
      question: 'Which of the following is NOT a front-end framework/library?',
      options: ['React', 'Angular', 'Express', 'Vue'],
      correctAnswer: 2
    },
    {
      id: 'web-9',
      question: 'What is the purpose of a CDN in web development?',
      options: [
        'To store database information',
        'To deliver content to users with high availability and performance',
        'To convert HTML to CSS',
        'To create animations on web pages'
      ],
      correctAnswer: 1
    },
    {
      id: 'web-10',
      question: 'Which tool is used for package management in JavaScript?',
      options: ['Webpack', 'Babel', 'npm', 'ESLint'],
      correctAnswer: 2
    }
  ],
  // Add similar questions for other domains as needed
};

// Sample courses, certifications, projects and jobs for Web Development
// In a real app, you would have data for all domains
export const courses: Record<string, Course[]> = {
  'web-dev': [
    {
      id: 'course-web-1',
      title: 'The Complete Web Developer in 2024: Zero to Mastery',
      provider: 'Udemy',
      url: '#',
      image: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b',
      price: '₹455',
      rating: 4.7,
      duration: '24 hours',
      level: 'Beginner',
    },
    {
      id: 'course-web-2',
      title: 'React - The Complete Guide (incl Hooks, React Router, Redux)',
      provider: 'Udemy',
      url: '#',
      image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158',
      price: '₹455',
      rating: 4.8,
      duration: '40 hours',
      level: 'All Levels',
    },
    {
      id: 'course-web-3',
      title: 'JavaScript: Understanding the Weird Parts',
      provider: 'Udemy',
      url: '#',
      image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6',
      price: '₹455',
      rating: 4.9,
      duration: '11.5 hours',
      level: 'Intermediate',
    },
    {
      id: 'course-web-4',
      title: 'Full Stack Web Development with Python and JavaScript',
      provider: 'Coursera',
      url: '#',
      image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d',
      price: 'Free with subscription',
      rating: 4.6,
      duration: '12 weeks',
      level: 'Advanced',
    },
    {
      id: 'course-web-5',
      title: 'Modern HTML & CSS From The Beginning',
      provider: 'Udemy',
      url: '#',
      image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085',
      price: '₹455',
      rating: 4.7,
      duration: '21 hours',
      level: 'Beginner',
    },
    {
      id: 'course-web-6',
      title: 'Advanced CSS and Sass: Flexbox, Grid, Animations and More!',
      provider: 'Udemy',
      url: '#',
      image: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05',
      price: '₹455',
      rating: 4.8,
      duration: '28 hours',
      level: 'Intermediate',
    },
    {
      id: 'course-web-7',
      title: 'Node.js, Express, MongoDB & More: The Complete Bootcamp',
      provider: 'Udemy',
      url: '#',
      image: 'https://images.unsplash.com/photo-1501854140801-50d01698950b',
      price: '₹455',
      rating: 4.7,
      duration: '42 hours',
      level: 'All Levels',
    },
    {
      id: 'course-web-8',
      title: 'GraphQL with React: The Complete Developers Guide',
      provider: 'Udemy',
      url: '#',
      image: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b',
      price: '₹455',
      rating: 4.6,
      duration: '15 hours',
      level: 'Intermediate',
    },
    {
      id: 'course-web-9',
      title: 'Web Development Bootcamp',
      provider: 'Codecademy',
      url: '#',
      image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d',
      price: 'Free with subscription',
      rating: 4.5,
      duration: '10 weeks',
      level: 'Beginner',
    },
    {
      id: 'course-web-10',
      title: 'TypeScript: The Complete Developer Guide',
      provider: 'Udemy',
      url: '#',
      image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6',
      price: '₹455',
      rating: 4.7,
      duration: '25 hours',
      level: 'All Levels',
    },
  ],
};

export const certifications: Record<string, Certification[]> = {
  'web-dev': [
    {
      id: 'cert-web-1',
      title: 'Meta Front-End Developer Professional Certificate',
      provider: 'Coursera',
      url: '#',
      image: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b',
      price: 'Free with subscription',
      duration: '7 months',
    },
    {
      id: 'cert-web-2',
      title: 'AWS Certified Developer - Associate',
      provider: 'Amazon Web Services',
      url: '#',
      image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158',
      price: '$150',
      duration: 'Self-paced',
    },
    {
      id: 'cert-web-3',
      title: 'Full Stack Web Development',
      provider: 'edX',
      url: '#',
      image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6',
      price: 'Free (certificate: $199)',
      duration: '16 weeks',
    },
    {
      id: 'cert-web-4',
      title: 'JavaScript Programming',
      provider: 'HackerRank',
      url: '#',
      image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d',
      price: 'Free',
      duration: 'Self-paced',
    },
    {
      id: 'cert-web-5',
      title: 'React Developer Certification',
      provider: 'W3Schools',
      url: '#',
      image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085',
      price: '$95',
      duration: 'Self-paced',
    },
    {
      id: 'cert-web-6',
      title: 'Professional Web Developer',
      provider: 'Microsoft',
      url: '#',
      image: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05',
      price: '$99',
      duration: 'Self-paced',
    },
    {
      id: 'cert-web-7',
      title: 'Full Stack JavaScript Techdegree',
      provider: 'Treehouse',
      url: '#',
      image: 'https://images.unsplash.com/photo-1501854140801-50d01698950b',
      price: '$199/month',
      duration: '3-9 months',
    },
    {
      id: 'cert-web-8',
      title: 'Node.js Application Developer (JSNAD)',
      provider: 'OpenJS Foundation',
      url: '#',
      image: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b',
      price: '$300',
      duration: 'Self-paced',
    },
    {
      id: 'cert-web-9',
      title: 'Advanced CSS and Sass',
      provider: 'Udemy',
      url: '#',
      image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d',
      price: '₹455',
      duration: 'Self-paced',
    },
    {
      id: 'cert-web-10',
      title: 'Modern Web Development',
      provider: 'LinkedIn Learning',
      url: '#',
      image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6',
      price: 'Subscription based',
      duration: 'Self-paced',
    },
  ],
};

export const projects: Record<string, Project[]> = {
  'web-dev': [
    {
      id: 'proj-web-1',
      title: 'Personal Portfolio Website',
      description: 'Create a responsive portfolio website to showcase your projects and skills.',
      difficulty: 'Easy',
      url: '#',
    },
    {
      id: 'proj-web-2',
      title: 'E-commerce Website',
      description: 'Build a full-featured online store with product listings, cart, and checkout.',
      difficulty: 'Intermediate',
      url: '#',
    },
    {
      id: 'proj-web-3',
      title: 'Weather App',
      description: 'Create a weather app that fetches data from a weather API and displays forecasts.',
      difficulty: 'Easy',
      url: '#',
    },
    {
      id: 'proj-web-4',
      title: 'Social Media Dashboard',
      description: 'Build an analytics dashboard for social media platforms with charts and stats.',
      difficulty: 'Intermediate',
      url: '#',
    },
    {
      id: 'proj-web-5',
      title: 'Real-time Chat Application',
      description: 'Develop a chat app with real-time messaging using WebSockets or Firebase.',
      difficulty: 'Hard',
      url: '#',
    },
    {
      id: 'proj-web-6',
      title: 'Task Management System',
      description: 'Create a Kanban-style task manager with drag and drop functionality.',
      difficulty: 'Intermediate',
      url: '#',
    },
    {
      id: 'proj-web-7',
      title: 'Blog Platform',
      description: 'Build a full-featured blog with articles, comments, and user authentication.',
      difficulty: 'Intermediate',
      url: '#',
    },
    {
      id: 'proj-web-8',
      title: 'Recipe Finder App',
      description: 'Create an app that helps users find recipes based on ingredients they have.',
      difficulty: 'Easy',
      url: '#',
    },
    {
      id: 'proj-web-9',
      title: 'Movie Streaming Dashboard',
      description: 'Develop a Netflix-like UI for browsing and watching videos.',
      difficulty: 'Hard',
      url: '#',
    },
    {
      id: 'proj-web-10',
      title: 'Online Quiz Application',
      description: 'Build an interactive quiz app with various categories and score tracking.',
      difficulty: 'Intermediate',
      url: '#',
    },
  ],
};

export const jobs: Record<string, Job[]> = {
  'web-dev': [
    {
      id: 'job-web-1',
      company: 'Google',
      logo: '/placeholder.svg',
      role: 'Frontend Developer',
      location: 'Bangalore, India',
      salary: '₹12,00,000 - ₹18,00,000',
      description: 'Join our team to build beautiful, responsive user interfaces for Google products.',
      requirements: [
        'Experience with JavaScript, HTML, CSS',
        'Knowledge of React or similar frameworks',
        'Understanding of web performance optimization',
        '3+ years of professional experience'
      ],
      url: '#',
    },
    {
      id: 'job-web-2',
      company: 'Microsoft',
      logo: '/placeholder.svg',
      role: 'Full Stack Developer',
      location: 'Hyderabad, India',
      salary: '₹14,00,000 - ₹22,00,000',
      description: 'Build end-to-end web applications for Microsoft services.',
      requirements: [
        'Strong JavaScript skills',
        'Experience with Node.js and React',
        'Database knowledge (SQL, NoSQL)',
        '5+ years of professional experience'
      ],
      url: '#',
    },
    {
      id: 'job-web-3',
      company: 'Amazon',
      logo: '/placeholder.svg',
      role: 'Web Development Engineer',
      location: 'Bangalore, India',
      salary: '₹15,00,000 - ₹25,00,000',
      description: 'Design and implement scalable web solutions for Amazon services.',
      requirements: [
        'Strong JavaScript and TypeScript skills',
        'Experience with modern frontend frameworks',
        'Knowledge of AWS services',
        '4+ years of professional experience'
      ],
      url: '#',
    },
    {
      id: 'job-web-4',
      company: 'Infosys',
      logo: '/placeholder.svg',
      role: 'Senior Web Developer',
      location: 'Pune, India',
      salary: '₹8,00,000 - ₹15,00,000',
      description: 'Lead web development projects for enterprise clients.',
      requirements: [
        'Frontend and backend development skills',
        'Experience with enterprise applications',
        'Team leadership experience',
        '7+ years of professional experience'
      ],
      url: '#',
    },
    {
      id: 'job-web-5',
      company: 'TCS',
      logo: '/placeholder.svg',
      role: 'Web Developer',
      location: 'Mumbai, India',
      salary: '₹6,00,000 - ₹12,00,000',
      description: 'Work on web applications for global clients across various industries.',
      requirements: [
        'HTML, CSS, JavaScript skills',
        'Experience with at least one modern framework',
        'Basic backend knowledge',
        '2+ years of professional experience'
      ],
      url: '#',
    },
    {
      id: 'job-web-6',
      company: 'Wipro',
      logo: '/placeholder.svg',
      role: 'Frontend Engineer',
      location: 'Bangalore, India',
      salary: '₹7,00,000 - ₹14,00,000',
      description: 'Create engaging user interfaces for enterprise applications.',
      requirements: [
        'Experience with React or Angular',
        'Strong CSS and responsive design skills',
        'Understanding of UI/UX principles',
        '3+ years of professional experience'
      ],
      url: '#',
    },
    {
      id: 'job-web-7',
      company: 'HCL Technologies',
      logo: '/placeholder.svg',
      role: 'Full Stack Web Developer',
      location: 'Noida, India',
      salary: '₹8,00,000 - ₹16,00,000',
      description: 'Develop end-to-end web solutions for global clients.',
      requirements: [
        'Frontend and backend development skills',
        'Experience with JS frameworks and Node.js',
        'Database design knowledge',
        '4+ years of professional experience'
      ],
      url: '#',
    },
    {
      id: 'job-web-8',
      company: 'Accenture',
      logo: '/placeholder.svg',
      role: 'Web Development Consultant',
      location: 'Hyderabad, India',
      salary: '₹10,00,000 - ₹18,00,000',
      description: 'Provide web development expertise for client projects.',
      requirements: [
        'Strong technical skills in web technologies',
        'Experience with large-scale applications',
        'Client communication skills',
        '5+ years of professional experience'
      ],
      url: '#',
    },
    {
      id: 'job-web-9',
      company: 'Cognizant',
      logo: '/placeholder.svg',
      role: 'UI Developer',
      location: 'Chennai, India',
      salary: '₹7,00,000 - ₹14,00,000',
      description: 'Create and implement user interfaces for web applications.',
      requirements: [
        'Strong HTML, CSS, JavaScript skills',
        'Experience with React or Angular',
        'Knowledge of CSS preprocessors',
        '3+ years of professional experience'
      ],
      url: '#',
    },
    {
      id: 'job-web-10',
      company: 'Tech Mahindra',
      logo: '/placeholder.svg',
      role: 'Web Application Developer',
      location: 'Pune, India',
      salary: '₹6,00,000 - ₹12,00,000',
      description: 'Build web applications for enterprise clients.',
      requirements: [
        'Frontend development skills',
        'Basic backend knowledge',
        'Understanding of software development lifecycle',
        '2+ years of professional experience'
      ],
      url: '#',
    },
  ],
};

// Add more mock data for other domains as needed
