
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import AnimatedSection from '@/components/AnimatedSection';
import { AppSidebar } from '@/components/AppSidebar';
import { getCurrentUser } from '@/lib/storage';

const Home = () => {
  const navigate = useNavigate();
  
  // Check if user is logged in
  useEffect(() => {
    const user = getCurrentUser();
    if (!user) {
      navigate('/');
    }
  }, [navigate]);
  
  // Get user data
  const user = getCurrentUser();
  
  return (
    <div className="min-h-screen bg-gray-50">
      <AppSidebar />
      
      <main className="md:ml-64 min-h-screen p-4 md:p-8">
        {/* Welcome Section */}
        <AnimatedSection>
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Welcome, {user?.name || 'User'}!</h1>
            <p className="text-gray-600 mt-2">Your journey to tech career success starts here.</p>
          </div>
        </AnimatedSection>
        
        {/* Getting Started Guide */}
        <AnimatedSection delay={200}>
          <Card className="mb-8 overflow-hidden">
            <div className="bg-gradient-to-r from-brand-blue to-brand-purple text-white p-6">
              <h2 className="text-2xl font-semibold">Getting Started with SkillTrack</h2>
              <p className="mt-2 opacity-90">Follow these steps to kickstart your tech career journey</p>
            </div>
            <CardContent className="p-6">
              <div className="space-y-6">
                <div className="flex gap-4 items-start">
                  <div className="w-10 h-10 bg-brand-blue bg-opacity-10 rounded-full flex items-center justify-center text-brand-blue flex-shrink-0">
                    <span className="font-semibold">1</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Choose the Right Domain</h3>
                    <p className="text-gray-600 mb-3">
                      Not sure which tech field is right for you? Our domain selection process helps you compare 
                      different tech fields and find the perfect match for your interests and aptitude.
                    </p>
                    <Button onClick={() => navigate('/domains')}>
                      Explore Domains
                    </Button>
                  </div>
                </div>
                
                <div className="flex gap-4 items-start">
                  <div className="w-10 h-10 bg-brand-purple bg-opacity-10 rounded-full flex items-center justify-center text-brand-purple flex-shrink-0">
                    <span className="font-semibold">2</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Follow Your Roadmap</h3>
                    <p className="text-gray-600 mb-3">
                      Once you've chosen a domain and taken the assessment test, you'll get a personalized 
                      learning path with step-by-step guidance on what to learn next.
                    </p>
                    {user?.selectedDomain ? (
                      <Button onClick={() => navigate('/roadmap')}>
                        View My Roadmap
                      </Button>
                    ) : (
                      <Button variant="outline" disabled>
                        Choose a Domain First
                      </Button>
                    )}
                  </div>
                </div>
                
                <div className="flex gap-4 items-start">
                  <div className="w-10 h-10 bg-brand-teal bg-opacity-10 rounded-full flex items-center justify-center text-brand-teal flex-shrink-0">
                    <span className="font-semibold">3</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-1">Apply for Domain-Specific Jobs</h3>
                    <p className="text-gray-600 mb-3">
                      Browse job listings tailored to your chosen domain, apply to positions that match 
                      your skills, and track your application status all in one place.
                    </p>
                    {user?.selectedDomain ? (
                      <Button onClick={() => navigate('/jobs')}>
                        Browse Jobs
                      </Button>
                    ) : (
                      <Button variant="outline" disabled>
                        Choose a Domain First
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </AnimatedSection>
        
        {/* Quick Stats */}
        <AnimatedSection delay={400}>
          <h2 className="text-2xl font-semibold mb-4">Your Progress</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Selected Domain</h3>
                <p className="text-2xl font-semibold">{user?.selectedDomain || 'Not Selected'}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Domain Level</h3>
                <p className="text-2xl font-semibold">{user?.domainLevel || 'Not Tested'}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Applied Jobs</h3>
                <p className="text-2xl font-semibold">
                  {user?.selectedDomain && user?.appliedJobs?.[user.selectedDomain]?.length || 0}
                  <span className="text-sm text-gray-500 ml-1">/ 5</span>
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-sm font-medium text-gray-500 mb-1">Resume Score</h3>
                <p className="text-2xl font-semibold">{user?.resumeAnalysis?.score || 'Not Analyzed'}</p>
              </CardContent>
            </Card>
          </div>
        </AnimatedSection>
        
        {/* Featured Resources */}
        <AnimatedSection delay={600}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-semibold">Featured Resources</h2>
            <Button variant="outline" onClick={() => navigate('/study')}>
              View All Resources
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="overflow-hidden">
              <div className="h-40 bg-gray-200">
                <img
                  src="https://images.unsplash.com/photo-1488590528505-98d2b5aba04b"
                  alt="Web Development"
                  className="w-full h-full object-cover"
                />
              </div>
              <CardContent className="p-4">
                <h3 className="font-medium mb-1 truncate">Getting Started with React</h3>
                <p className="text-sm text-gray-500 mb-3">Learn the fundamentals of React.js</p>
                <Button variant="outline" size="sm" className="w-full">
                  Learn More
                </Button>
              </CardContent>
            </Card>
            
            <Card className="overflow-hidden">
              <div className="h-40 bg-gray-200">
                <img
                  src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6"
                  alt="Programming"
                  className="w-full h-full object-cover"
                />
              </div>
              <CardContent className="p-4">
                <h3 className="font-medium mb-1 truncate">SQL Database Fundamentals</h3>
                <p className="text-sm text-gray-500 mb-3">Master database queries with SQL</p>
                <Button variant="outline" size="sm" className="w-full">
                  Learn More
                </Button>
              </CardContent>
            </Card>
            
            <Card className="overflow-hidden">
              <div className="h-40 bg-gray-200">
                <img
                  src="https://images.unsplash.com/photo-1498050108023-c5249f4df085"
                  alt="Coding"
                  className="w-full h-full object-cover"
                />
              </div>
              <CardContent className="p-4">
                <h3 className="font-medium mb-1 truncate">Building an E-commerce App</h3>
                <p className="text-sm text-gray-500 mb-3">Project-based learning for intermediates</p>
                <Button variant="outline" size="sm" className="w-full">
                  Learn More
                </Button>
              </CardContent>
            </Card>
          </div>
        </AnimatedSection>
        
        {/* Job Alert */}
        <AnimatedSection delay={800} className="mt-8">
          <Card className="border-l-4 border-brand-blue">
            <CardContent className="p-6">
              <div className="flex items-start">
                <div className="bg-brand-blue bg-opacity-10 p-3 rounded-full mr-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-brand-blue" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-1">Job Alert</h3>
                  <p className="text-gray-600 mb-3">We have 25+ new job listings that match your profile!</p>
                  <Button onClick={() => navigate('/jobs')}>
                    Browse Jobs
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </AnimatedSection>
      </main>
    </div>
  );
};

export default Home;
