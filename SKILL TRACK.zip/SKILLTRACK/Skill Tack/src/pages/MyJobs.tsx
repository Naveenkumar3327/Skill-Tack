
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppSidebar } from '@/components/AppSidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Building, Briefcase, Clock, CheckCircle, XCircle } from 'lucide-react';
import { Job } from '@/data/domainData';
import { getCurrentUser } from '@/lib/storage';
import AnimatedSection from '@/components/AnimatedSection';
import { toast } from 'sonner';

type JobWithStatus = Job & {
  status: 'Pending' | 'Shortlisted' | 'Rejected';
  domain: string;
};

const MyJobs = () => {
  const navigate = useNavigate();
  const [appliedJobs, setAppliedJobs] = useState<JobWithStatus[]>([]);
  const [currentTab, setCurrentTab] = useState('all');
  const [filteredJobs, setFilteredJobs] = useState<JobWithStatus[]>([]);

  useEffect(() => {
    const user = getCurrentUser();
    if (!user) {
      toast.error('Please sign in to view your applied jobs');
      navigate('/');
      return;
    }

    // Get all applied jobs across all domains
    const allJobs: JobWithStatus[] = [];
    if (user.appliedJobs) {
      Object.entries(user.appliedJobs).forEach(([domain, jobs]) => {
        jobs.forEach((job: any) => {
          allJobs.push({
            ...job,
            domain
          });
        });
      });
    }

    setAppliedJobs(allJobs);
    setFilteredJobs(allJobs);
  }, [navigate]);

  useEffect(() => {
    if (currentTab === 'all') {
      setFilteredJobs(appliedJobs);
    } else {
      setFilteredJobs(appliedJobs.filter(job => job.status.toLowerCase() === currentTab));
    }
  }, [currentTab, appliedJobs]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Pending':
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        );
      case 'Shortlisted':
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <CheckCircle className="h-3 w-3 mr-1" />
            Shortlisted
          </Badge>
        );
      case 'Rejected':
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            <XCircle className="h-3 w-3 mr-1" />
            Rejected
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <AppSidebar />
      <div className="flex-1 p-8 pt-6 sm:ml-64">
        <div className="max-w-5xl mx-auto">
          <AnimatedSection>
            <h1 className="text-3xl font-bold tracking-tight mb-2">My Job Applications</h1>
            <p className="text-muted-foreground mb-8">
              Track the status of your job applications across all domains.
            </p>
          </AnimatedSection>

          <Tabs defaultValue="all" onValueChange={setCurrentTab}>
            <AnimatedSection>
              <TabsList className="mb-8">
                <TabsTrigger value="all">All Applications</TabsTrigger>
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="shortlisted">Shortlisted</TabsTrigger>
                <TabsTrigger value="rejected">Rejected</TabsTrigger>
              </TabsList>
            </AnimatedSection>

            <TabsContent value="all" className="mt-0">
              <div className="space-y-4">
                {renderJobsList(filteredJobs, getStatusBadge)}
              </div>
            </TabsContent>
            
            <TabsContent value="pending" className="mt-0">
              <div className="space-y-4">
                {renderJobsList(filteredJobs, getStatusBadge)}
              </div>
            </TabsContent>
            
            <TabsContent value="shortlisted" className="mt-0">
              <div className="space-y-4">
                {renderJobsList(filteredJobs, getStatusBadge)}
              </div>
            </TabsContent>
            
            <TabsContent value="rejected" className="mt-0">
              <div className="space-y-4">
                {renderJobsList(filteredJobs, getStatusBadge)}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

// Helper function to render the list of jobs
const renderJobsList = (jobs: JobWithStatus[], getStatusBadge: (status: string) => JSX.Element | null) => {
  if (jobs.length === 0) {
    return (
      <AnimatedSection>
        <div className="text-center py-12">
          <Briefcase className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-4 text-lg font-medium">No applications found</h3>
          <p className="mt-1 text-muted-foreground">
            You haven't applied to any jobs in this category yet.
          </p>
        </div>
      </AnimatedSection>
    );
  }

  return jobs.map((job, index) => (
    <AnimatedSection key={`${job.id}-${job.domain}`} delay={index * 50}>
      <Card>
        <CardHeader className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-md bg-gray-100 overflow-hidden flex items-center justify-center">
                {job.logo ? (
                  <img src={job.logo} alt={job.company} className="w-full h-full object-cover" />
                ) : (
                  <Building className="h-6 w-6 text-gray-400" />
                )}
              </div>
              <div>
                <CardTitle className="text-xl">{job.role}</CardTitle>
                <div className="text-muted-foreground">{job.company}</div>
              </div>
            </div>
            <div className="flex flex-col sm:items-end gap-2">
              {getStatusBadge(job.status)}
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                {job.domain}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6 pt-0">
          <div className="mb-4">
            <p className="text-sm">{job.description}</p>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="font-medium">Location</p>
              <p className="text-muted-foreground">{job.location}</p>
            </div>
            <div>
              <p className="font-medium">Salary</p>
              <p className="text-muted-foreground">{job.salary}</p>
            </div>
            <div className="col-span-2">
              <p className="font-medium">Applied Date</p>
              <p className="text-muted-foreground">{new Date().toLocaleDateString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </AnimatedSection>
  ));
};

export default MyJobs;
