
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppSidebar } from '@/components/AppSidebar';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Search, MapPin, Briefcase, Building, CheckCircle } from 'lucide-react';
import { Job, jobs } from '@/data/domainData';
import { getCurrentUser, applyToJob } from '@/lib/storage';
import AnimatedSection from '@/components/AnimatedSection';
import { toast } from 'sonner';

const JobOffers = () => {
  const navigate = useNavigate();
  const [domainId, setDomainId] = useState<string | undefined>(undefined);
  const [domainName, setDomainName] = useState<string>('');
  const [domainJobs, setDomainJobs] = useState<Job[]>([]);
  const [filteredJobs, setFilteredJobs] = useState<Job[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isApplying, setIsApplying] = useState(false);
  const [appliedJobs, setAppliedJobs] = useState<string[]>([]);

  useEffect(() => {
    const user = getCurrentUser();
    if (!user || !user.selectedDomain) {
      toast.error('Please select a domain first');
      navigate('/domains');
      return;
    }

    // Get the domain ID from the selected domain name
    const selectedDomainName = user.selectedDomain;
    setDomainName(selectedDomainName);
    const selectedDomainId = selectedDomainName.toLowerCase().replace(/\s+/g, '-');
    setDomainId(selectedDomainId);

    // Load domain-specific jobs
    const domainSpecificJobs = jobs[selectedDomainId] || [];
    setDomainJobs(domainSpecificJobs);
    setFilteredJobs(domainSpecificJobs);

    // Get list of applied jobs
    if (user.appliedJobs && user.appliedJobs[selectedDomainName]) {
      const appliedJobIds = user.appliedJobs[selectedDomainName].map(job => job.id);
      setAppliedJobs(appliedJobIds);
    } else {
      setAppliedJobs([]);
    }
  }, [navigate]);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredJobs(domainJobs);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = domainJobs.filter(
        job => 
          job.company.toLowerCase().includes(query) ||
          job.role.toLowerCase().includes(query) ||
          job.location.toLowerCase().includes(query) ||
          job.description.toLowerCase().includes(query) ||
          job.requirements.some(req => req.toLowerCase().includes(query))
      );
      setFilteredJobs(filtered);
    }
  }, [searchQuery, domainJobs]);

  const handleViewJob = (job: Job) => {
    setSelectedJob(job);
    setIsDialogOpen(true);
  };

  const handleApplyJob = async () => {
    if (!selectedJob || !domainId || isApplying) return;
    
    setIsApplying(true);
    try {
      // Add domain info and status to the job
      const jobWithDomainAndStatus = {
        ...selectedJob,
        domain: domainName,
        status: 'Pending' as const // Use a const assertion to fix the type
      };
      
      await applyToJob(jobWithDomainAndStatus);
      
      // Update local state to reflect the application
      setAppliedJobs(prev => [...prev, selectedJob.id]);
      toast.success('Job application submitted successfully!');
      
      // Close dialog after successful application
      setIsDialogOpen(false);
    } catch (error: any) {
      toast.error(error.message || 'Failed to apply for this job');
    } finally {
      setIsApplying(false);
    }
  };

  if (!domainId) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <AppSidebar />
      <div className="flex-1 p-8 pt-6 sm:ml-64">
        <div className="max-w-6xl mx-auto">
          <AnimatedSection>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
              <div>
                <h1 className="text-3xl font-bold tracking-tight mb-2">Job Offers</h1>
                <p className="text-muted-foreground">
                  Find job opportunities in {domainName}. You can apply for up to 5 jobs per domain.
                </p>
              </div>
              <div className="relative mt-4 md:mt-0 w-full md:w-auto md:min-w-[300px]">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                <Input
                  placeholder="Search jobs by title, company, or skill..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </AnimatedSection>

          <div className="grid grid-cols-1 gap-6">
            {filteredJobs.length > 0 ? (
              filteredJobs.map((job, index) => (
                <AnimatedSection key={job.id} delay={index * 50}>
                  <Card className="overflow-hidden hover:shadow-md transition-shadow">
                    <CardHeader className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex gap-4">
                          <div className="w-12 h-12 rounded-md bg-gray-100 overflow-hidden flex items-center justify-center">
                            {job.logo ? (
                              <img src={job.logo} alt={job.company} className="w-full h-full object-cover" />
                            ) : (
                              <Building className="h-6 w-6 text-gray-400" />
                            )}
                          </div>
                          <div>
                            <CardTitle className="text-xl">{job.role}</CardTitle>
                            <p className="text-muted-foreground">{job.company}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">{job.salary}</p>
                          <div className="flex items-center mt-1 text-muted-foreground text-sm">
                            <MapPin className="h-4 w-4 mr-1" />
                            {job.location}
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6 pt-0">
                      <p className="line-clamp-2 text-gray-600 mb-4">
                        {job.description}
                      </p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {job.requirements.slice(0, 3).map((req, i) => (
                          <Badge key={i} variant="outline">
                            {req.split(' ').slice(0, 3).join(' ')}
                            {req.split(' ').length > 3 ? '...' : ''}
                          </Badge>
                        ))}
                        {job.requirements.length > 3 && (
                          <Badge variant="outline">+{job.requirements.length - 3} more</Badge>
                        )}
                      </div>
                    </CardContent>
                    <Separator />
                    <CardFooter className="p-6">
                      <div className="w-full flex justify-between items-center">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewJob(job)}
                        >
                          View Details
                        </Button>
                        {appliedJobs.includes(job.id) ? (
                          <div className="flex items-center text-green-600">
                            <CheckCircle className="h-4 w-4 mr-1" />
                            <span className="text-sm font-medium">Applied</span>
                          </div>
                        ) : (
                          <Button 
                            size="sm"
                            onClick={() => {
                              setSelectedJob(job);
                              handleApplyJob();
                            }}
                            disabled={appliedJobs.length >= 5}
                          >
                            Apply Now
                          </Button>
                        )}
                      </div>
                    </CardFooter>
                  </Card>
                </AnimatedSection>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <Briefcase className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-4 text-lg font-medium">No jobs found</h3>
                <p className="mt-1 text-muted-foreground">
                  Try adjusting your search or come back later for new opportunities.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Job Details Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          {selectedJob && (
            <>
              <DialogHeader>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-md bg-gray-100 overflow-hidden flex items-center justify-center">
                    {selectedJob.logo ? (
                      <img src={selectedJob.logo} alt={selectedJob.company} className="w-full h-full object-cover" />
                    ) : (
                      <Building className="h-6 w-6 text-gray-400" />
                    )}
                  </div>
                  <div>
                    <DialogTitle className="text-xl">{selectedJob.role}</DialogTitle>
                    <DialogDescription>
                      {selectedJob.company} • {selectedJob.location}
                    </DialogDescription>
                  </div>
                </div>
              </DialogHeader>

              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Salary Range</h4>
                  <p>{selectedJob.salary}</p>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Job Description</h4>
                  <p>{selectedJob.description}</p>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Requirements</h4>
                  <ul className="list-disc pl-5 space-y-1">
                    {selectedJob.requirements.map((req, i) => (
                      <li key={i}>{req}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <DialogFooter className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  {appliedJobs.includes(selectedJob.id) 
                    ? 'You have already applied to this job.' 
                    : appliedJobs.length >= 5 
                      ? 'You have reached the maximum number of job applications for this domain.' 
                      : 'You can apply to 5 jobs per domain.'}
                </div>
                <Button
                  onClick={handleApplyJob}
                  disabled={appliedJobs.includes(selectedJob.id) || appliedJobs.length >= 5 || isApplying}
                >
                  {isApplying ? 'Applying...' : appliedJobs.includes(selectedJob.id) ? 'Applied' : 'Apply Now'}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default JobOffers;
