
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppSidebar } from '@/components/AppSidebar';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Star } from "lucide-react";
import { Course, Certification, Project, courses, certifications, projects } from '@/data/domainData';
import { getCurrentUser } from '@/lib/storage';
import AnimatedSection from '@/components/AnimatedSection';
import { toast } from 'sonner';

const Study = () => {
  const navigate = useNavigate();
  const [domainId, setDomainId] = useState<string | undefined>(undefined);
  const [domainCourses, setDomainCourses] = useState<Course[]>([]);
  const [domainCertifications, setDomainCertifications] = useState<Certification[]>([]);
  const [domainProjects, setDomainProjects] = useState<Project[]>([]);

  useEffect(() => {
    const user = getCurrentUser();
    if (!user || !user.selectedDomain) {
      toast.error('Please select a domain first');
      navigate('/domains');
      return;
    }

    // Get the domain ID from the selected domain name
    const selectedDomainId = user.selectedDomain.toLowerCase().replace(/\s+/g, '-');
    setDomainId(selectedDomainId);

    // Load domain-specific resources
    setDomainCourses(courses[selectedDomainId] || []);
    setDomainCertifications(certifications[selectedDomainId] || []);
    setDomainProjects(projects[selectedDomainId] || []);
  }, [navigate]);

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, i) => (
      <Star 
        key={i} 
        size={16} 
        className={i < Math.round(rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}
      />
    ));
  };

  if (!domainId) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <AppSidebar />
      <div className="flex-1 p-8 pt-6 sm:ml-64">
        <div className="max-w-5xl mx-auto">
          <AnimatedSection>
            <h1 className="text-3xl font-bold tracking-tight mb-6">Study Resources</h1>
            <p className="text-muted-foreground mb-8">
              Personalized learning resources for your domain. Choose from courses, certifications, and projects to accelerate your career.
            </p>
          </AnimatedSection>

          <Tabs defaultValue="courses" className="mt-6">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="courses">Courses</TabsTrigger>
              <TabsTrigger value="certifications">Certifications</TabsTrigger>
              <TabsTrigger value="projects">Projects</TabsTrigger>
            </TabsList>

            <TabsContent value="courses" className="mt-0">
              <AnimatedSection delay={100}>
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {domainCourses.map((course) => (
                    <Card key={course.id} className="overflow-hidden hover:shadow-md transition-shadow">
                      <div className="aspect-video w-full overflow-hidden bg-muted">
                        <img
                          src={course.image}
                          alt={course.title}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <CardHeader className="p-4">
                        <CardTitle className="text-lg">{course.title}</CardTitle>
                        <CardDescription className="flex justify-between">
                          <span>{course.provider}</span>
                          <span className="flex items-center gap-1">
                            {renderStars(course.rating)}
                          </span>
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="p-4 pt-0 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Duration: {course.duration}</span>
                          <span className="font-medium">{course.price}</span>
                        </div>
                        <div className="mt-1">
                          <span className="inline-block px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                            {course.level}
                          </span>
                        </div>
                      </CardContent>
                      <CardFooter className="p-4 pt-0">
                        <Button asChild className="w-full" variant="secondary">
                          <a href={course.url} target="_blank" rel="noopener noreferrer">
                            View Course
                          </a>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </AnimatedSection>
            </TabsContent>

            <TabsContent value="certifications" className="mt-0">
              <AnimatedSection delay={100}>
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {domainCertifications.map((cert) => (
                    <Card key={cert.id} className="overflow-hidden hover:shadow-md transition-shadow">
                      <div className="aspect-video w-full overflow-hidden bg-muted">
                        <img
                          src={cert.image}
                          alt={cert.title}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <CardHeader className="p-4">
                        <CardTitle className="text-lg">{cert.title}</CardTitle>
                        <CardDescription>{cert.provider}</CardDescription>
                      </CardHeader>
                      <CardContent className="p-4 pt-0 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Duration: {cert.duration}</span>
                          <span className="font-medium">{cert.price}</span>
                        </div>
                      </CardContent>
                      <CardFooter className="p-4 pt-0">
                        <Button asChild className="w-full" variant="secondary">
                          <a href={cert.url} target="_blank" rel="noopener noreferrer">
                            Learn More
                          </a>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </AnimatedSection>
            </TabsContent>

            <TabsContent value="projects" className="mt-0">
              <AnimatedSection delay={100}>
                <div className="grid gap-6">
                  {domainProjects.map((project) => (
                    <Card key={project.id} className="hover:shadow-md transition-shadow">
                      <CardHeader className="p-5">
                        <div className="flex justify-between items-center">
                          <CardTitle className="text-xl">{project.title}</CardTitle>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            project.difficulty === 'Easy' ? 'bg-green-100 text-green-800' : 
                            project.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' : 
                            'bg-red-100 text-red-800'
                          }`}>
                            {project.difficulty}
                          </span>
                        </div>
                      </CardHeader>
                      <CardContent className="p-5 pt-0">
                        <p>{project.description}</p>
                      </CardContent>
                      <CardFooter className="p-5 pt-0">
                        <Button asChild variant="outline">
                          <a href={project.url} target="_blank" rel="noopener noreferrer">
                            View Project
                          </a>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </AnimatedSection>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Study;
