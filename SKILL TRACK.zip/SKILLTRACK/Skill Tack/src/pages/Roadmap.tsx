
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppSidebar } from '@/components/AppSidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight, Check } from 'lucide-react';
import { getCurrentUser } from '@/lib/storage';
import AnimatedSection from '@/components/AnimatedSection';
import { toast } from 'sonner';

interface RoadmapStep {
  id: number;
  title: string;
  description: string;
  resources?: string[];
  completed?: boolean;
}

interface RoadmapLevel {
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Pro';
  steps: RoadmapStep[];
}

// Mock data for roadmaps
const roadmapData: Record<string, RoadmapLevel[]> = {
  'web-dev': [
    {
      level: 'Beginner',
      steps: [
        {
          id: 1,
          title: 'HTML & CSS Fundamentals',
          description: 'Learn the basics of HTML structure and CSS styling to create static web pages.',
          resources: [
            'MDN Web Docs - HTML Basics',
            'CSS Tricks - CSS Basics',
            'freeCodeCamp - Responsive Web Design'
          ]
        },
        {
          id: 2,
          title: 'JavaScript Basics',
          description: 'Master fundamental JavaScript concepts like variables, functions, and DOM manipulation.',
          resources: [
            'JavaScript.info - The Modern JavaScript Tutorial',
            'Eloquent JavaScript Book',
            'freeCodeCamp - JavaScript Algorithms and Data Structures'
          ]
        },
        {
          id: 3,
          title: 'Responsive Design',
          description: 'Learn to create websites that work well on all devices using media queries and flexible layouts.',
          resources: [
            'CSS Media Queries',
            'Flexbox and Grid layouts',
            'Mobile-First Design principles'
          ]
        },
        {
          id: 4,
          title: 'Version Control with Git',
          description: 'Learn to track and manage code changes using Git and GitHub.',
          resources: [
            'Git Documentation',
            'GitHub Guides',
            'Git Branching - Basic Branching and Merging'
          ]
        }
      ]
    },
    {
      level: 'Intermediate',
      steps: [
        {
          id: 5,
          title: 'Front-end Frameworks',
          description: 'Learn React, Vue, or Angular to build interactive user interfaces.',
          resources: [
            'React Documentation',
            'Vue.js Documentation',
            'Angular Documentation'
          ]
        },
        {
          id: 6,
          title: 'State Management',
          description: 'Manage application state using tools like Redux, Vuex, or Context API.',
          resources: [
            'Redux Documentation',
            'Vuex Documentation',
            'Using React Context API'
          ]
        },
        {
          id: 7,
          title: 'API Integration',
          description: 'Connect your front-end to back-end services using REST and GraphQL.',
          resources: [
            'Working with Fetch API',
            'Axios Documentation',
            'GraphQL Introduction'
          ]
        },
        {
          id: 8,
          title: 'Testing',
          description: 'Write unit and integration tests for your applications.',
          resources: [
            'Jest Documentation',
            'React Testing Library',
            'Cypress for E2E Testing'
          ]
        }
      ]
    },
    {
      level: 'Advanced',
      steps: [
        {
          id: 9,
          title: 'Server-Side Rendering',
          description: 'Improve performance and SEO with server-side rendering frameworks.',
          resources: [
            'Next.js Documentation',
            'Nuxt.js Documentation',
            'Angular Universal'
          ]
        },
        {
          id: 10,
          title: 'Performance Optimization',
          description: 'Optimize your applications for speed and efficiency.',
          resources: [
            'Web Vitals',
            'Lighthouse Audits',
            'Bundle Size Optimization'
          ]
        },
        {
          id: 11,
          title: 'Advanced State Management',
          description: 'Implement sophisticated state management patterns and middleware.',
          resources: [
            'Redux Middleware',
            'Redux Saga',
            'MobX'
          ]
        },
        {
          id: 12,
          title: 'Progressive Web Apps',
          description: 'Create web applications that work offline and feel like native apps.',
          resources: [
            'PWA Documentation',
            'Service Workers',
            'Web App Manifest'
          ]
        }
      ]
    },
    {
      level: 'Pro',
      steps: [
        {
          id: 13,
          title: 'Micro Frontends',
          description: 'Build and compose multiple frontend applications into a cohesive product.',
          resources: [
            'Micro Frontends Introduction',
            'Module Federation',
            'Web Components'
          ]
        },
        {
          id: 14,
          title: 'Serverless Architecture',
          description: 'Deploy frontend applications using serverless technologies.',
          resources: [
            'AWS Lambda',
            'Netlify Functions',
            'Vercel Serverless Functions'
          ]
        },
        {
          id: 15,
          title: 'WebAssembly',
          description: 'Use WebAssembly to run high-performance code in browsers.',
          resources: [
            'WebAssembly Documentation',
            'Rust and WebAssembly',
            'Emscripten'
          ]
        },
        {
          id: 16,
          title: 'Advanced Animations',
          description: 'Create complex animations and interactive experiences.',
          resources: [
            'GSAP',
            'Three.js',
            'WebGL'
          ]
        }
      ]
    }
  ],
  // Add more domains here with their respective roadmaps
  'data-science': [
    {
      level: 'Beginner',
      steps: [
        {
          id: 1,
          title: 'Programming Fundamentals',
          description: 'Learn Python programming basics, essential for data science.',
          resources: [
            'Python Documentation',
            'Codecademy Python Course',
            'Python for Data Science Handbook'
          ]
        },
        {
          id: 2,
          title: 'Statistics Fundamentals',
          description: 'Master basic statistical concepts needed for data analysis.',
          resources: [
            'Khan Academy Statistics',
            'Statistics for Data Science',
            'Probability Theory Basics'
          ]
        },
        {
          id: 3,
          title: 'Data Manipulation',
          description: 'Learn to clean, transform, and manipulate data using Pandas.',
          resources: [
            'Pandas Documentation',
            'Data Cleaning with Pandas',
            'Data Wrangling Techniques'
          ]
        },
        {
          id: 4,
          title: 'Data Visualization',
          description: 'Create insightful visualizations using matplotlib and seaborn.',
          resources: [
            'Matplotlib Documentation',
            'Seaborn Documentation',
            'Data Visualization Best Practices'
          ]
        }
      ]
    },
    {
      level: 'Intermediate',
      steps: [
        // Similar structure as web-dev
        {
          id: 5,
          title: 'Machine Learning Basics',
          description: 'Understand fundamental ML algorithms and concepts.',
          resources: [
            'Scikit-learn Documentation',
            'Machine Learning Crash Course by Google',
            'Introduction to Statistical Learning'
          ]
        },
        {
          id: 6,
          title: 'Feature Engineering',
          description: 'Learn to create and select features for ML models.',
          resources: [
            'Feature Engineering for Machine Learning',
            'Feature Selection Techniques',
            'Dimensionality Reduction'
          ]
        }
      ]
    },
    {
      level: 'Advanced',
      steps: [
        // Similar structure as web-dev
        {
          id: 7,
          title: 'Deep Learning',
          description: 'Master neural networks and deep learning techniques.',
          resources: [
            'TensorFlow Documentation',
            'PyTorch Tutorials',
            'Deep Learning Book by Goodfellow'
          ]
        }
      ]
    },
    {
      level: 'Pro',
      steps: [
        // Similar structure as web-dev
        {
          id: 8,
          title: 'MLOps',
          description: 'Deploy and maintain ML models in production.',
          resources: [
            'MLflow Documentation',
            'Kubeflow',
            'Model Monitoring and Management'
          ]
        }
      ]
    }
  ]
};

const Roadmap = () => {
  const navigate = useNavigate();
  const [domainId, setDomainId] = useState<string | undefined>(undefined);
  const [userLevel, setUserLevel] = useState<string>('Beginner');
  const [roadmap, setRoadmap] = useState<RoadmapLevel[]>([]);
  
  useEffect(() => {
    const user = getCurrentUser();
    if (!user || !user.selectedDomain) {
      toast.error('Please select a domain first');
      navigate('/domains');
      return;
    }

    // Get the domain ID and user level
    const selectedDomainId = user.selectedDomain.toLowerCase().replace(/\s+/g, '-');
    setDomainId(selectedDomainId);
    
    if (user.domainLevel) {
      setUserLevel(user.domainLevel);
    }

    // Load roadmap for the selected domain
    const domainRoadmap = roadmapData[selectedDomainId] || [];
    setRoadmap(domainRoadmap);
  }, [navigate]);

  // Mock function to toggle step completion
  const toggleStepCompletion = (levelIndex: number, stepId: number) => {
    setRoadmap((prevRoadmap) => {
      const newRoadmap = [...prevRoadmap];
      const stepIndex = newRoadmap[levelIndex].steps.findIndex(step => step.id === stepId);
      if (stepIndex !== -1) {
        const steps = [...newRoadmap[levelIndex].steps];
        steps[stepIndex] = {
          ...steps[stepIndex],
          completed: !steps[stepIndex].completed
        };
        newRoadmap[levelIndex] = {
          ...newRoadmap[levelIndex],
          steps
        };
      }
      return newRoadmap;
    });
  };

  if (!domainId || roadmap.length === 0) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <AppSidebar />
      <div className="flex-1 p-8 pt-6 sm:ml-64">
        <div className="max-w-5xl mx-auto">
          <AnimatedSection>
            <h1 className="text-3xl font-bold tracking-tight mb-2">Your Learning Roadmap</h1>
            <p className="text-muted-foreground mb-8">
              Based on your test results, you're at the <span className="font-medium text-primary">{userLevel}</span> level.
              Follow this personalized roadmap to advance your skills.
            </p>
          </AnimatedSection>

          <div className="space-y-12">
            {roadmap.map((level, levelIndex) => (
              <AnimatedSection key={level.level} delay={levelIndex * 100}>
                <div className="mb-4">
                  <h2 className="text-2xl font-semibold inline-flex items-center">
                    {level.level} Level
                    {userLevel === level.level && (
                      <span className="ml-2 text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">
                        Current Level
                      </span>
                    )}
                  </h2>
                  <div className="h-1 w-20 bg-primary mt-2"></div>
                </div>

                <div className="relative pb-8">
                  <div className="absolute left-7 top-0 bottom-0 w-0.5 bg-gray-200"></div>

                  <div className="space-y-8">
                    {level.steps.map((step) => (
                      <div key={step.id} className="relative">
                        <div
                          className={`absolute left-0 w-14 h-14 rounded-full flex items-center justify-center ${
                            step.completed
                              ? 'bg-green-100 text-green-600'
                              : 'bg-gray-100 text-gray-500'
                          }`}
                          onClick={() => toggleStepCompletion(levelIndex, step.id)}
                        >
                          {step.completed ? <Check size={24} /> : step.id}
                        </div>

                        <Card className="ml-20">
                          <CardHeader>
                            <CardTitle>{step.title}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-gray-600 mb-4">{step.description}</p>
                            
                            {step.resources && (
                              <div>
                                <h4 className="text-sm font-medium mb-2">Recommended Resources:</h4>
                                <ul className="space-y-1">
                                  {step.resources.map((resource, i) => (
                                    <li key={i} className="flex items-center text-sm text-blue-600">
                                      <ArrowRight size={12} className="mr-1" />
                                      <span>{resource}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      </div>
                    ))}
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Roadmap;
