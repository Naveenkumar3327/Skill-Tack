
import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="text-center max-w-md">
        <div className="bg-white p-8 rounded-lg shadow-md">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-brand-blue to-brand-purple bg-clip-text text-transparent">404</h1>
          <p className="text-xl text-gray-700 mt-4 mb-6">Oops! This page doesn't exist.</p>
          <p className="text-gray-500 mb-8">
            The page you're looking for couldn't be found. It might have been moved or deleted.
          </p>
          <Button 
            className="bg-gradient-to-r from-brand-blue to-brand-purple hover:opacity-90"
            onClick={() => navigate('/')}
          >
            Return to Home
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
