
import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AppSidebar } from '@/components/AppSidebar';
import AnimatedSection from '@/components/AnimatedSection';
import DomainCard from '@/components/DomainCard';
import { Domain, domains } from '@/data/domainData';

const Domains = () => {
  const [selectedTab, setSelectedTab] = useState('all');
  const [comparisonDomains, setComparisonDomains] = useState<Domain[]>([]);
  
  // Handle domain selection for comparison
  const toggleDomainSelection = (domain: Domain) => {
    // If already selected, remove it
    if (comparisonDomains.some(d => d.id === domain.id)) {
      setComparisonDomains(comparisonDomains.filter(d => d.id !== domain.id));
    } 
    // If less than 3 domains are selected, add it
    else if (comparisonDomains.length < 3) {
      setComparisonDomains([...comparisonDomains, domain]);
    }
    // If 3 domains are already selected, replace the first one
    else {
      const newDomains = [...comparisonDomains];
      newDomains.shift(); // Remove the first domain
      newDomains.push(domain); // Add the new domain
      setComparisonDomains(newDomains);
    }
  };
  
  // Group domains by category for the tabs
  const techDomains = domains.filter(d => ['web-dev', 'mobile-dev', 'game-dev', 'ui-ux'].includes(d.id));
  const dataDomains = domains.filter(d => ['data-science', 'ai-ml'].includes(d.id));
  const infraDomains = domains.filter(d => ['cloud-computing', 'devops', 'cybersecurity', 'blockchain'].includes(d.id));
  
  return (
    <div className="min-h-screen bg-gray-50">
      <AppSidebar />
      
      <main className="md:ml-64 min-h-screen p-4 md:p-8">
        <AnimatedSection>
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Choose Your Tech Domain</h1>
            <p className="text-gray-600 mt-2">
              Explore and compare different tech domains to find the perfect match for your skills and interests.
            </p>
          </div>
        </AnimatedSection>
        
        {/* Domain Comparison Section */}
        <AnimatedSection delay={200}>
          <Card className="mb-8">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Domain Comparison</h2>
              <p className="text-gray-600 mb-6">
                Select up to 3 domains to compare them side by side. This will help you make an informed decision.
              </p>
              
              {comparisonDomains.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  {comparisonDomains.map(domain => (
                    <div key={domain.id} className="relative">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="absolute top-2 right-2 z-10 bg-white rounded-full"
                        onClick={() => toggleDomainSelection(domain)}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </Button>
                      <DomainCard domain={domain} variant="compact" />
                    </div>
                  ))}
                  
                  {/* Fill empty slots with placeholder cards */}
                  {Array.from({ length: 3 - comparisonDomains.length }).map((_, index) => (
                    <Card key={`empty-${index}`} className="border-dashed border-2 border-gray-300 flex items-center justify-center h-48">
                      <p className="text-gray-500 text-center px-4">
                        Select another domain to compare
                      </p>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 text-center mb-6">
                  <p className="text-gray-600">
                    No domains selected for comparison. Select domains from below to compare them.
                  </p>
                </div>
              )}
              
              {/* Comparison details */}
              {comparisonDomains.length > 0 && (
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b">
                        <th className="pb-3 pr-4 font-medium"></th>
                        {comparisonDomains.map(domain => (
                          <th key={domain.id} className="pb-3 px-4 font-medium">{domain.name}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="py-3 pr-4 font-medium">Average Salary</td>
                        {comparisonDomains.map(domain => (
                          <td key={domain.id} className="py-3 px-4">{domain.avgSalary}</td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 pr-4 font-medium">Top Companies</td>
                        {comparisonDomains.map(domain => (
                          <td key={domain.id} className="py-3 px-4">
                            <ul className="list-disc list-inside">
                              {domain.topCompanies.slice(0, 3).map(company => (
                                <li key={company}>{company}</li>
                              ))}
                            </ul>
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 pr-4 font-medium">Latest Technologies</td>
                        {comparisonDomains.map(domain => (
                          <td key={domain.id} className="py-3 px-4">
                            <ul className="list-disc list-inside">
                              {domain.latestTech.slice(0, 3).map(tech => (
                                <li key={tech}>{tech}</li>
                              ))}
                            </ul>
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </AnimatedSection>
        
        {/* Browse Domains Section */}
        <AnimatedSection delay={400}>
          <div className="mb-6">
            <h2 className="text-xl font-semibold">Browse Domains</h2>
            <p className="text-gray-600">Explore all available tech domains or filter by category.</p>
          </div>
          
          <Tabs defaultValue="all" value={selectedTab} onValueChange={setSelectedTab} className="mb-8">
            <TabsList className="mb-6">
              <TabsTrigger value="all">All Domains</TabsTrigger>
              <TabsTrigger value="tech">Web & Mobile</TabsTrigger>
              <TabsTrigger value="data">Data & AI</TabsTrigger>
              <TabsTrigger value="infra">Infrastructure</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {domains.map(domain => (
                  <DomainCard 
                    key={domain.id} 
                    domain={domain}
                    selected={comparisonDomains.some(d => d.id === domain.id)}
                    onSelect={() => toggleDomainSelection(domain)}
                  />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="tech" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {techDomains.map(domain => (
                  <DomainCard 
                    key={domain.id} 
                    domain={domain} 
                    selected={comparisonDomains.some(d => d.id === domain.id)}
                    onSelect={() => toggleDomainSelection(domain)}
                  />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="data" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {dataDomains.map(domain => (
                  <DomainCard 
                    key={domain.id} 
                    domain={domain} 
                    selected={comparisonDomains.some(d => d.id === domain.id)}
                    onSelect={() => toggleDomainSelection(domain)}
                  />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="infra" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {infraDomains.map(domain => (
                  <DomainCard 
                    key={domain.id} 
                    domain={domain}
                    selected={comparisonDomains.some(d => d.id === domain.id)}
                    onSelect={() => toggleDomainSelection(domain)}
                  />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </AnimatedSection>
      </main>
    </div>
  );
};

export default Domains;
