
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppSidebar } from '@/components/AppSidebar';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { ArrowRight, Clock } from 'lucide-react';
import { domainQuestions, Question } from '@/data/domainData';
import { getCurrentUser, updateDomainTestScore } from '@/lib/storage';
import AnimatedSection from '@/components/AnimatedSection';
import { toast } from 'sonner';

const DailyTest = () => {
  const navigate = useNavigate();
  const [domainId, setDomainId] = useState<string | undefined>(undefined);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [isTestStarted, setIsTestStarted] = useState(false);
  const [isTestCompleted, setIsTestCompleted] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes in seconds

  useEffect(() => {
    const user = getCurrentUser();
    if (!user || !user.selectedDomain) {
      toast.error('Please select a domain first');
      navigate('/domains');
      return;
    }

    // Get the domain ID from the selected domain name
    const selectedDomainId = user.selectedDomain.toLowerCase().replace(/\s+/g, '-');
    setDomainId(selectedDomainId);

    // Load domain-specific questions
    const domainSpecificQuestions = domainQuestions[selectedDomainId] || [];
    setQuestions(domainSpecificQuestions);
    
    // Reset selected answers
    setSelectedAnswers(new Array(domainSpecificQuestions.length).fill(-1));
  }, [navigate]);

  useEffect(() => {
    let timer: number;
    if (isTestStarted && !isTestCompleted && timeLeft > 0) {
      timer = window.setTimeout(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
    } else if (timeLeft === 0 && !isTestCompleted && isTestStarted) {
      handleCompleteTest();
    }

    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [isTestStarted, isTestCompleted, timeLeft]);

  // Handle fullscreen exit to auto-submit
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && isTestStarted && !isTestCompleted) {
        toast.info('Test auto-submitted due to page change');
        handleCompleteTest();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isTestStarted, isTestCompleted]);

  const handleStartTest = () => {
    setIsTestStarted(true);
    setIsTestCompleted(false);
    setCurrentQuestionIndex(0);
    setSelectedAnswers(new Array(questions.length).fill(-1));
    setTimeLeft(600);
    document.documentElement.requestFullscreen().catch(err => {
      toast.warning('Fullscreen mode not available. Please focus on the test.');
    });
  };

  const handleSelectAnswer = (questionIndex: number, answerIndex: number) => {
    setSelectedAnswers(prev => {
      const newAnswers = [...prev];
      newAnswers[questionIndex] = answerIndex;
      return newAnswers;
    });
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleCompleteTest = () => {
    // Exit fullscreen if active
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(err => {
        console.error('Error exiting fullscreen:', err);
      });
    }

    // Calculate score
    let correctAnswers = 0;
    questions.forEach((question, index) => {
      if (selectedAnswers[index] === question.correctAnswer) {
        correctAnswers++;
      }
    });

    const calculatedScore = Math.round((correctAnswers / questions.length) * 100);
    setScore(calculatedScore);
    setIsTestCompleted(true);

    // Save score to localStorage if domain is selected
    if (domainId) {
      try {
        updateDomainTestScore(domainId, calculatedScore);
        toast.success('Test score saved successfully');
      } catch (error) {
        console.error('Error saving test score:', error);
        toast.error('Failed to save test score');
      }
    }
  };

  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  if (!domainId || questions.length === 0) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <AppSidebar />
      <div className="flex-1 p-8 pt-6 sm:ml-64">
        <div className="max-w-4xl mx-auto">
          {!isTestStarted && !isTestCompleted ? (
            <AnimatedSection>
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="text-2xl">Daily Test</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="mb-6">
                    This test contains {questions.length} questions related to your chosen domain. 
                    You will have 10 minutes to complete the test. The test will auto-submit if:
                  </p>
                  <ul className="list-disc pl-5 mb-6 space-y-2">
                    <li>Time runs out</li>
                    <li>You exit fullscreen mode</li>
                    <li>You navigate away from this page</li>
                  </ul>
                  <p className="mb-6">
                    Your score will be saved to your profile and can be used to track your progress.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleStartTest}>
                    Start Test
                  </Button>
                </CardFooter>
              </Card>
            </AnimatedSection>
          ) : isTestCompleted ? (
            <AnimatedSection>
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl">Test Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-8">
                    <div className="text-center">
                      <p className="text-lg mb-2">Your score:</p>
                      <p className="text-5xl font-bold mb-4">{score}%</p>
                      <p className="text-lg">
                        {score <= 45 ? 'Beginner Level' :
                         score <= 60 ? 'Intermediate Level' :
                         score <= 75 ? 'Advanced Level' : 'Pro Level'}
                      </p>
                    </div>

                    <div>
                      <h3 className="text-lg font-medium mb-2">Score Breakdown:</h3>
                      <ul className="space-y-2">
                        <li className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-green-500"></div>
                          <span>Correct Answers: {questions.filter((q, i) => selectedAnswers[i] === q.correctAnswer).length}</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-red-500"></div>
                          <span>Incorrect Answers: {questions.filter((q, i) => selectedAnswers[i] !== -1 && selectedAnswers[i] !== q.correctAnswer).length}</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-gray-300"></div>
                          <span>Unanswered: {questions.filter((q, i) => selectedAnswers[i] === -1).length}</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" onClick={() => navigate('/home')}>
                    Return to Home
                  </Button>
                </CardFooter>
              </Card>
            </AnimatedSection>
          ) : (
            <>
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h1 className="text-2xl font-bold">Daily Test</h1>
                  <p className="text-muted-foreground">Question {currentQuestionIndex + 1} of {questions.length}</p>
                </div>
                <div className="flex items-center gap-2 text-orange-500">
                  <Clock size={20} />
                  <span className="font-medium">{formatTime(timeLeft)}</span>
                </div>
              </div>

              <Progress 
                value={((currentQuestionIndex + 1) / questions.length) * 100} 
                className="mb-8 h-2"
              />

              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="text-xl">
                    {questions[currentQuestionIndex].question}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={selectedAnswers[currentQuestionIndex]?.toString()}
                    onValueChange={(value) => handleSelectAnswer(currentQuestionIndex, parseInt(value))}
                    className="space-y-4"
                  >
                    {questions[currentQuestionIndex].options.map((option, optionIndex) => (
                      <div key={optionIndex} className="flex items-center space-x-2">
                        <RadioGroupItem value={optionIndex.toString()} id={`option-${optionIndex}`} />
                        <Label htmlFor={`option-${optionIndex}`} className="text-base">{option}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button
                    variant="outline"
                    onClick={handlePrevQuestion}
                    disabled={currentQuestionIndex === 0}
                  >
                    Previous
                  </Button>

                  {currentQuestionIndex < questions.length - 1 ? (
                    <Button onClick={handleNextQuestion}>
                      Next <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  ) : (
                    <Button onClick={handleCompleteTest}>
                      Submit Test
                    </Button>
                  )}
                </CardFooter>
              </Card>

              <div className="flex justify-center">
                <div className="flex gap-2">
                  {questions.map((_, index) => (
                    <button
                      key={index}
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                        index === currentQuestionIndex
                          ? 'bg-primary text-primary-foreground'
                          : selectedAnswers[index] !== -1
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-600'
                      }`}
                      onClick={() => setCurrentQuestionIndex(index)}
                    >
                      {index + 1}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default DailyTest;
