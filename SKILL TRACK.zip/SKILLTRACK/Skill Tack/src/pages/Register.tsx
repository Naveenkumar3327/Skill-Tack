
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { AuthForm } from '@/components/AuthForm';
import AnimatedSection from '@/components/AnimatedSection';
import { getCurrentUser } from '@/lib/storage';

const Register = () => {
  const navigate = useNavigate();
  
  // Check if user is already logged in
  useEffect(() => {
    const user = getCurrentUser();
    if (user) {
      navigate('/home');
    }
  }, [navigate]);
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 
              className="text-2xl font-bold bg-gradient-to-r from-brand-blue to-brand-purple bg-clip-text text-transparent"
              onClick={() => navigate('/')}
              style={{ cursor: 'pointer' }}
            >
              SkillTrack
            </h1>
            <span className="ml-2 text-sm text-gray-500">Your Career Launchpad</span>
          </div>
          <Button variant="default" onClick={() => navigate('/')}>Sign In</Button>
        </div>
      </header>
      
      {/* Registration Form */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="max-w-md mx-auto">
              <h2 className="text-3xl font-bold mb-6 text-center">Create Your Account</h2>
              <div className="bg-white rounded-lg p-6 shadow-md">
                <AuthForm type="register" />
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>
      
      {/* Benefits */}
      <section className="py-12 mb-10">
        <div className="container mx-auto px-4">
          <AnimatedSection delay={300}>
            <h3 className="text-xl font-semibold text-center mb-8">Join SkillTrack to access:</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="w-16 h-16 bg-brand-blue bg-opacity-10 rounded-full flex items-center justify-center text-brand-blue mb-4 mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                </div>
                <h4 className="font-medium text-lg mb-2">Domain-Specific Tests</h4>
                <p className="text-gray-600 text-sm">Find your perfect tech domain with our specialized assessment tests.</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="w-16 h-16 bg-brand-purple bg-opacity-10 rounded-full flex items-center justify-center text-brand-purple mb-4 mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <h4 className="font-medium text-lg mb-2">Personalized Roadmaps</h4>
                <p className="text-gray-600 text-sm">Follow custom learning paths tailored to your skill level.</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-sm text-center">
                <div className="w-16 h-16 bg-brand-teal bg-opacity-10 rounded-full flex items-center justify-center text-brand-teal mb-4 mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <h4 className="font-medium text-lg mb-2">Job Application Tracking</h4>
                <p className="text-gray-600 text-sm">Apply to relevant positions and track your application status.</p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-auto">
        <div className="container mx-auto px-4 text-center">
          <p className="mb-4">&copy; {new Date().getFullYear()} SkillTrack. All rights reserved.</p>
          <div className="flex justify-center gap-4">
            <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Privacy Policy</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Terms of Service</a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Contact Us</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Register;
