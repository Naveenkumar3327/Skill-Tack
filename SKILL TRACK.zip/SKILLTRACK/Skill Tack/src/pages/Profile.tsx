import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppSidebar } from '@/components/AppSidebar';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { BarChart as BarChartIcon, Home, BookOpen, Award, Github, Linkedin } from 'lucide-react';
import { getCurrentUser, User, Job } from '@/lib/storage';
import { domains } from '@/data/domainData';
import AnimatedSection from '@/components/AnimatedSection';
import { toast } from 'sonner';
import { Bar, BarChart as RechartsBarChart, LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const Profile = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [domainInfo, setDomainInfo] = useState<any>(null);
  const [userStatistics, setUserStatistics] = useState({
    testScores: [] as { domain: string; score: number }[],
    appliedJobs: [] as Job[],
    totalApplications: 0
  });

  useEffect(() => {
    const currentUser = getCurrentUser();
    if (!currentUser) {
      toast.error('Please sign in to view your profile');
      navigate('/');
      return;
    }

    setUser(currentUser);

    // Get domain info
    if (currentUser.selectedDomain) {
      const domainData = domains.find(d => 
        d.name.toLowerCase() === currentUser.selectedDomain?.toLowerCase()
      );
      setDomainInfo(domainData);
    }

    // Process user statistics
    if (currentUser.testScores) {
      const testScores = Object.entries(currentUser.testScores).map(([domain, score]) => ({
        domain,
        score
      }));
      
      // Get all applied jobs across domains
      const allJobs: Job[] = [];
      let totalApplications = 0;
      
      if (currentUser.appliedJobs) {
        Object.entries(currentUser.appliedJobs).forEach(([domain, jobs]) => {
          totalApplications += jobs.length;
          jobs.forEach((job: Job) => {
            allJobs.push(job);
          });
        });
      }

      setUserStatistics({
        testScores,
        appliedJobs: allJobs,
        totalApplications
      });
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('skilltrack_current_user');
    toast.success('Logged out successfully');
    navigate('/');
  };

  if (!user) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <AppSidebar />
      <div className="flex-1 p-8 pt-6 sm:ml-64">
        <div className="max-w-6xl mx-auto">
          <AnimatedSection>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6 mb-8">
              <div className="flex items-center gap-4">
                <Avatar className="h-24 w-24">
                  <AvatarFallback className="text-2xl bg-gradient-to-r from-brand-blue to-brand-purple text-white">
                    {user.name ? user.name.substring(0, 2).toUpperCase() : 'U'}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h1 className="text-3xl font-bold tracking-tight">{user.name || 'User'}</h1>
                  <p className="text-muted-foreground">{user.email}</p>
                  
                  <div className="flex gap-2 mt-2">
                    {user.selectedDomain && (
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        {user.selectedDomain}
                      </Badge>
                    )}
                    {user.domainLevel && (
                      <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                        {user.domainLevel} Level
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
              
              <Button variant="outline" onClick={handleLogout}>
                Log Out
              </Button>
            </div>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* Domain Progress Card */}
            <AnimatedSection delay={100}>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Domain Level</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col items-center">
                    <div className="w-24 h-24 rounded-full bg-gradient-to-r from-brand-blue to-brand-purple flex items-center justify-center text-white font-bold text-3xl mb-4">
                      {user.testScores && user.selectedDomain && user.testScores[user.selectedDomain] 
                        ? `${user.testScores[user.selectedDomain]}%`
                        : '0%'}
                    </div>
                    <p className="text-lg font-medium">
                      {user.domainLevel || 'Not Tested'}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {user.selectedDomain || 'No domain selected'}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </AnimatedSection>

            {/* Job Applications Card */}
            <AnimatedSection delay={200}>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Job Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <p className="text-5xl font-bold mb-2">{userStatistics.totalApplications}</p>
                    <p className="text-muted-foreground">Total Applications</p>
                    
                    <div className="flex justify-center gap-4 mt-4">
                      <div>
                        <p className="text-2xl font-medium">
                          {userStatistics.appliedJobs.filter(job => job.status === 'Pending').length}
                        </p>
                        <p className="text-xs text-muted-foreground">Pending</p>
                      </div>
                      <div>
                        <p className="text-2xl font-medium">
                          {userStatistics.appliedJobs.filter(job => job.status === 'Shortlisted').length}
                        </p>
                        <p className="text-xs text-muted-foreground">Shortlisted</p>
                      </div>
                      <div>
                        <p className="text-2xl font-medium">
                          {userStatistics.appliedJobs.filter(job => job.status === 'Rejected').length}
                        </p>
                        <p className="text-xs text-muted-foreground">Rejected</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </AnimatedSection>

            {/* Resume Score Card */}
            <AnimatedSection delay={300}>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Resume Score</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <p className="text-5xl font-bold mb-2">
                      {user.resumeAnalysis ? `${user.resumeAnalysis.score}%` : '---'}
                    </p>
                    <p className="text-muted-foreground">ATS Compatibility</p>
                    
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => navigate('/resume')}
                    >
                      {user.resumeAnalysis ? 'View Analysis' : 'Analyze Resume'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </AnimatedSection>
          </div>

          <Tabs defaultValue="overview" className="mb-8">
            <AnimatedSection delay={100}>
              <TabsList className="mb-6">
                <TabsTrigger value="overview">
                  <Home className="w-4 h-4 mr-2" />
                  Overview
                </TabsTrigger>
                <TabsTrigger value="performance">
                  <BarChartIcon className="w-4 h-4 mr-2" />
                  Performance
                </TabsTrigger>
                <TabsTrigger value="education">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Education
                </TabsTrigger>
                <TabsTrigger value="settings">
                  <Award className="w-4 h-4 mr-2" />
                  Achievements
                </TabsTrigger>
              </TabsList>
            </AnimatedSection>

            <TabsContent value="overview" className="mt-0">
              <div className="grid md:grid-cols-2 gap-6">
                <AnimatedSection delay={200}>
                  <Card>
                    <CardHeader>
                      <CardTitle>Domain Information</CardTitle>
                      <CardDescription>
                        Details about your selected domain
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {domainInfo ? (
                        <div className="space-y-4">
                          <div>
                            <h3 className="text-lg font-medium flex items-center">
                              <span className="text-xl mr-2">{domainInfo.icon}</span>
                              {domainInfo.name}
                            </h3>
                            <p className="text-muted-foreground mt-1">
                              {domainInfo.description}
                            </p>
                          </div>
                          
                          <div>
                            <h4 className="font-medium">Average Salary</h4>
                            <p>{domainInfo.avgSalary}</p>
                          </div>
                          
                          <div>
                            <h4 className="font-medium">Top Companies</h4>
                            <div className="flex flex-wrap gap-2 mt-1">
                              {domainInfo.topCompanies.map((company: string) => (
                                <Badge key={company} variant="secondary">
                                  {company}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          
                          <div>
                            <h4 className="font-medium">Latest Technologies</h4>
                            <div className="flex flex-wrap gap-2 mt-1">
                              {domainInfo.latestTech.map((tech: string) => (
                                <Badge key={tech} variant="outline">
                                  {tech}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center p-6">
                          <p className="text-muted-foreground">No domain selected yet.</p>
                          <Button 
                            variant="secondary" 
                            className="mt-4"
                            onClick={() => navigate('/domains')}
                          >
                            Choose a Domain
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </AnimatedSection>

                <AnimatedSection delay={300}>
                  <Card>
                    <CardHeader>
                      <CardTitle>Test Scores</CardTitle>
                      <CardDescription>
                        Your performance on domain tests
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {userStatistics.testScores.length > 0 ? (
                        <div className="h-60">
                          <ResponsiveContainer width="100%" height="100%">
                            <RechartsBarChart
                              data={userStatistics.testScores}
                              margin={{
                                top: 5,
                                right: 30,
                                left: 20,
                                bottom: 5,
                              }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="domain" />
                              <YAxis />
                              <Tooltip />
                              <Legend />
                              <Bar dataKey="score" fill="#8884d8" name="Score %" />
                            </RechartsBarChart>
                          </ResponsiveContainer>
                        </div>
                      ) : (
                        <div className="text-center p-6">
                          <p className="text-muted-foreground">No test scores yet.</p>
                          <Button 
                            variant="secondary" 
                            className="mt-4"
                            onClick={() => navigate('/daily-test')}
                          >
                            Take a Test
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </AnimatedSection>
              </div>
            </TabsContent>
            
            <TabsContent value="performance" className="mt-0">
              <AnimatedSection delay={100}>
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Metrics</CardTitle>
                    <CardDescription>Track your progress over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsLineChart
                          data={[
                            {name: 'Week 1', score: 65},
                            {name: 'Week 2', score: 70},
                            {name: 'Week 3', score: 68},
                            {name: 'Week 4', score: 75},
                            {name: 'Week 5', score: 80},
                          ]}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line type="monotone" dataKey="score" stroke="#8884d8" />
                        </RechartsLineChart>
                      </ResponsiveContainer>
                    </div>
                    
                    <p className="text-center text-muted-foreground mt-4">
                      This chart shows your simulated weekly performance trends.
                    </p>
                  </CardContent>
                </Card>
              </AnimatedSection>
            </TabsContent>
            
            <TabsContent value="education" className="mt-0">
              <AnimatedSection delay={100}>
                <Card>
                  <CardHeader>
                    <CardTitle>Education Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <label className="text-sm font-medium">Degree/Qualification</label>
                        <Input 
                          placeholder="e.g., Bachelor of Technology" 
                          defaultValue="Bachelor of Computer Science"
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">Institution</label>
                        <Input 
                          placeholder="e.g., University Name" 
                          defaultValue="Delhi Technological University"
                          className="mt-1"
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium">Year Started</label>
                          <Input 
                            placeholder="e.g., 2019" 
                            defaultValue="2020"
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Year Completed</label>
                          <Input 
                            placeholder="e.g., 2023" 
                            defaultValue="2024"
                            className="mt-1"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">Description/Achievements</label>
                        <Textarea 
                          placeholder="Describe your educational achievements..." 
                          defaultValue="Graduated with distinction. Participated in multiple hackathons and coding competitions. Led the college's web development club."
                          className="mt-1"
                        />
                      </div>
                      
                      <Button>Save Changes</Button>
                    </div>
                  </CardContent>
                </Card>
              </AnimatedSection>
            </TabsContent>
            
            <TabsContent value="settings" className="mt-0">
              <AnimatedSection delay={100}>
                <Card>
                  <CardHeader>
                    <CardTitle>Achievements & Certifications</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="font-medium">Web Development Bootcamp</h3>
                        <p className="text-sm text-muted-foreground">Udemy • Completed on March 2023</p>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="font-medium">Advanced JavaScript Masterclass</h3>
                        <p className="text-sm text-muted-foreground">Codecademy • Completed on June 2023</p>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="font-medium">React Developer Certificate</h3>
                        <p className="text-sm text-muted-foreground">Meta • Completed on September 2023</p>
                      </div>
                      
                      <div className="mt-6">
                        <h3 className="font-medium mb-4">Social Profiles</h3>
                        
                        <div className="space-y-4">
                          <div className="flex items-center gap-2">
                            <Github className="h-5 w-5" />
                            <Input 
                              placeholder="GitHub Profile URL" 
                              defaultValue="https://github.com/username"
                            />
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Linkedin className="h-5 w-5" />
                            <Input 
                              placeholder="LinkedIn Profile URL" 
                              defaultValue="https://linkedin.com/in/username"
                            />
                          </div>
                        </div>
                        
                        <Button className="mt-4">Save Changes</Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </AnimatedSection>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Profile;
