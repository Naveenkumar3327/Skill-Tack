
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { AuthForm } from '@/components/AuthForm';
import { TestimonialsCarousel } from '@/components/TestimonialsCarousel';
import AnimatedSection from '@/components/AnimatedSection';
import { getCurrentUser } from '@/lib/storage';

const Index = () => {
  const navigate = useNavigate();
  
  // Check if user is already logged in
  useEffect(() => {
    const user = getCurrentUser();
    if (user) {
      navigate('/home');
    }
  }, [navigate]);
  
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-brand-blue to-brand-purple bg-clip-text text-transparent">SKillSync</h1>
            <span className="ml-2 text-sm text-gray-500">Your Career Launchpad</span>
          </div>
          <nav className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate('/register')}>Sign Up</Button>
            <Button variant="default" onClick={() => document.getElementById('login-section')?.scrollIntoView({ behavior: 'smooth' })}>Sign In</Button>
          </nav>
        </div>
      </header>
      
      {/* Hero section */}
      <section className="bg-gradient-to-r from-brand-blue to-brand-purple py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0 text-white">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Launch Your Tech Career The Right Way</h1>
              <p className="text-xl mb-6 opacity-90">Discover your perfect tech domain, master the required skills, and land your dream job.</p>
              <Button 
                size="lg" 
                className="bg-white text-brand-blue hover:bg-gray-100"
                onClick={() => navigate('/register')}
              >
                Get Started Now
              </Button>
            </div>
            <div className="md:w-1/2 md:pl-10">
              <div className="bg-white p-6 rounded-lg shadow-lg">
                <img 
                  src="https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d" 
                  alt="Person using laptop"
                  className="rounded-lg w-full object-cover h-64" 
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* How it works */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <h2 className="text-3xl font-bold mb-12 text-center">How SkillTrack Works</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <AnimatedSection delay={200} className="bg-white p-6 rounded-lg shadow-sm">
                <div className="w-16 h-16 bg-brand-blue bg-opacity-10 rounded-full flex items-center justify-center text-brand-blue mb-4">
                  <span className="text-2xl font-bold">1</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Discover Your Domain</h3>
                <p className="text-gray-600">Take our specialized domain assessment test to find the perfect tech field that matches your skills and interests.</p>
              </AnimatedSection>
              
              <AnimatedSection delay={400} className="bg-white p-6 rounded-lg shadow-sm">
                <div className="w-16 h-16 bg-brand-purple bg-opacity-10 rounded-full flex items-center justify-center text-brand-purple mb-4">
                  <span className="text-2xl font-bold">2</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Follow Your Roadmap</h3>
                <p className="text-gray-600">Get a personalized learning path with curated courses, certifications, and projects to master your chosen domain.</p>
              </AnimatedSection>
              
              <AnimatedSection delay={600} className="bg-white p-6 rounded-lg shadow-sm">
                <div className="w-16 h-16 bg-brand-teal bg-opacity-10 rounded-full flex items-center justify-center text-brand-teal mb-4">
                  <span className="text-2xl font-bold">3</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Land Your Dream Job</h3>
                <p className="text-gray-600">Apply to domain-specific job openings, track your applications, and optimize your resume with our AI analyzer.</p>
              </AnimatedSection>
            </div>
          </AnimatedSection>
        </div>
      </section>
      
      {/* Benefits section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="flex flex-col md:flex-row items-center md:items-start gap-10">
              <div className="md:w-1/2">
                <h2 className="text-3xl font-bold mb-6">Why Choose the Right Domain?</h2>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <div className="mr-4 mt-1 bg-green-100 p-1 rounded-full text-green-600">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Higher Job Satisfaction</h3>
                      <p className="text-gray-600">Working in a field that aligns with your interests and strengths leads to greater job satisfaction and career longevity.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-4 mt-1 bg-green-100 p-1 rounded-full text-green-600">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Faster Career Growth</h3>
                      <p className="text-gray-600">Specializing in the right domain allows you to develop deep expertise, leading to faster promotions and salary increases.</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-4 mt-1 bg-green-100 p-1 rounded-full text-green-600">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">Better Learning Efficiency</h3>
                      <p className="text-gray-600">Following a structured roadmap helps you learn efficiently without wasting time on irrelevant skills or resources.</p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="md:w-1/2">
                <img 
                  src="https://images.unsplash.com/photo-1498050108023-c5249f4df085" 
                  alt="Career growth"
                  className="rounded-lg shadow-md w-full object-cover h-auto md:h-80" 
                />
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>
      
      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <h2 className="text-3xl font-bold mb-10 text-center">Student Success Stories</h2>
            <TestimonialsCarousel />
          </AnimatedSection>
        </div>
      </section>
      
      {/* Login section */}
      <section id="login-section" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <AnimatedSection>
            <div className="max-w-md mx-auto">
              <h2 className="text-3xl font-bold mb-6 text-center">Sign In</h2>
              <div className="bg-white rounded-lg p-6 shadow-md">
                <AuthForm type="login" />
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <h2 className="text-2xl font-bold">SkillTrack</h2>
              <p className="text-gray-400 mt-1">Your Personalized Career Launchpad</p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Contact Us</a>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-gray-800 text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} SkillTrack. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
