
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { AppSidebar } from '@/components/AppSidebar';
import { domains, domainQuestions } from '@/data/domainData';
import { updateDomainTestScore, updateUserDomain } from '@/lib/storage';

const DomainTest = () => {
  const { domainId } = useParams<{ domainId: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  const domain = domains.find(d => d.id === domainId);
  const questions = domainId ? domainQuestions[domainId] || [] : [];
  
  // If domain not found, redirect to domains page
  useEffect(() => {
    if (!domain) {
      toast({
        title: "Domain not found",
        description: "The selected domain doesn't exist.",
        variant: "destructive",
      });
      navigate('/domains');
    }
  }, [domain, navigate, toast]);
  
  // Set up test timer (10 minutes)
  useEffect(() => {
    if (!timeRemaining) {
      setTimeRemaining(10 * 60); // 10 minutes in seconds
    }
    
    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev && prev > 0) return prev - 1;
        else {
          handleSubmitTest();
          clearInterval(timer);
          return 0;
        }
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);
  
  // Format time remaining
  const formatTimeRemaining = () => {
    if (timeRemaining === null) return "00:00";
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };
  
  // Handle fullscreen mode
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
      
      // Auto submit if exiting fullscreen
      if (!document.fullscreenElement && !showResults) {
        toast({
          title: "Test Exited",
          description: "Exiting fullscreen mode automatically submits your test.",
        });
        handleSubmitTest();
      }
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, [showResults]);
  
  // Enter fullscreen mode
  const enterFullscreen = async () => {
    try {
      await document.documentElement.requestFullscreen();
    } catch (err) {
      toast({
        title: "Fullscreen Error",
        description: "Unable to enter fullscreen mode. The test will continue without it.",
        variant: "destructive",
      });
    }
  };
  
  // Handle option selection
  const handleSelectAnswer = (questionIndex: number, optionIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[questionIndex] = optionIndex;
    setSelectedAnswers(newAnswers);
  };
  
  // Go to next question
  const goToNextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };
  
  // Go to previous question
  const goToPreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };
  
  // Calculate score and submit test
  const handleSubmitTest = () => {
    // Calculate score
    let correctAnswers = 0;
    questions.forEach((question, index) => {
      if (selectedAnswers[index] === question.correctAnswer) {
        correctAnswers++;
      }
    });
    
    const calculatedScore = Math.round((correctAnswers / questions.length) * 100);
    setScore(calculatedScore);
    
    // Save score to local storage
    if (domainId) {
      updateUserDomain(domainId);
      updateDomainTestScore(domainId, calculatedScore);
    }
    
    setShowResults(true);
    
    // Exit fullscreen if active
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(err => console.error(err));
    }
  };
  
  // Get level based on score
  const getLevelFromScore = (score: number) => {
    if (score <= 45) return "Beginner";
    if (score <= 60) return "Intermediate";
    if (score <= 75) return "Advanced";
    return "Pro";
  };
  
  // Start the test
  const startTest = () => {
    enterFullscreen();
  };
  
  // If domain not found, show loading
  if (!domain || questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      {!isFullscreen && <AppSidebar />}
      
      <main className={`${!isFullscreen ? 'md:ml-64' : ''} min-h-screen p-4 md:p-8`}>
        {!isFullscreen && !showResults ? (
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader className="bg-gradient-to-r from-brand-blue to-brand-purple text-white p-6">
                <h1 className="text-2xl font-bold">Domain Test: {domain.name}</h1>
                <p className="mt-2 opacity-90">Test your knowledge and find your skill level</p>
              </CardHeader>
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">Test Instructions</h2>
                <ul className="list-disc list-inside mb-6 space-y-2">
                  <li>This test contains {questions.length} multiple-choice questions.</li>
                  <li>You have 10 minutes to complete the test.</li>
                  <li>The test will run in fullscreen mode. Exiting fullscreen will submit your test automatically.</li>
                  <li>Your score determines your level: Beginner (0-45), Intermediate (46-60), Advanced (61-75), or Pro (76-100).</li>
                </ul>
                <p className="font-medium">Are you ready to start the test?</p>
              </CardContent>
              <CardFooter className="p-6 pt-0">
                <Button onClick={startTest}>Start Test</Button>
              </CardFooter>
            </Card>
          </div>
        ) : showResults ? (
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader className="bg-gradient-to-r from-brand-blue to-brand-purple text-white p-6">
                <h1 className="text-2xl font-bold">Test Results: {domain.name}</h1>
                <p className="mt-2 opacity-90">Your domain knowledge level</p>
              </CardHeader>
              <CardContent className="p-6">
                <div className="text-center mb-8">
                  <div className="inline-flex items-center justify-center w-32 h-32 rounded-full bg-brand-blue bg-opacity-10 mb-4">
                    <span className="text-4xl font-bold text-brand-blue">{score}%</span>
                  </div>
                  <h2 className="text-2xl font-semibold">
                    You are at {getLevelFromScore(score)} level
                  </h2>
                  <p className="text-gray-600 mt-2">
                    You answered {selectedAnswers.filter((answer, i) => answer === questions[i].correctAnswer).length} 
                    {' '}out of {questions.length} questions correctly.
                  </p>
                </div>
                
                <div className="bg-gray-50 p-6 rounded-lg mb-6">
                  <h3 className="font-semibold mb-4">What Your Level Means:</h3>
                  <ul className="space-y-3">
                    {getLevelFromScore(score) === "Beginner" && (
                      <li className="flex gap-2">
                        <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                          <span className="text-blue-600 text-sm font-semibold">B</span>
                        </div>
                        <p>You're just starting out in this domain. We'll focus on building a strong foundation of fundamentals.</p>
                      </li>
                    )}
                    {getLevelFromScore(score) === "Intermediate" && (
                      <li className="flex gap-2">
                        <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                          <span className="text-green-600 text-sm font-semibold">I</span>
                        </div>
                        <p>You have a good grasp of the basics. We'll help you advance your skills and tackle more complex topics.</p>
                      </li>
                    )}
                    {getLevelFromScore(score) === "Advanced" && (
                      <li className="flex gap-2">
                        <div className="w-6 h-6 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                          <span className="text-purple-600 text-sm font-semibold">A</span>
                        </div>
                        <p>You have strong knowledge in this domain. We'll focus on specialized skills and real-world applications.</p>
                      </li>
                    )}
                    {getLevelFromScore(score) === "Pro" && (
                      <li className="flex gap-2">
                        <div className="w-6 h-6 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
                          <span className="text-orange-600 text-sm font-semibold">P</span>
                        </div>
                        <p>You're at an expert level. We'll challenge you with cutting-edge concepts and advanced techniques.</p>
                      </li>
                    )}
                  </ul>
                </div>
              </CardContent>
              <CardFooter className="p-6 pt-0 flex flex-col sm:flex-row gap-3">
                <Button onClick={() => navigate('/roadmap')}>View My Roadmap</Button>
                <Button variant="outline" onClick={() => navigate('/domains')}>Back to Domains</Button>
              </CardFooter>
            </Card>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto">
            {/* Test timer and progress */}
            <div className="mb-6 bg-white p-4 shadow rounded-lg flex justify-between items-center">
              <div>
                <h1 className="text-xl font-bold">{domain.name} Domain Test</h1>
                <p className="text-sm text-gray-600">Question {currentQuestion + 1} of {questions.length}</p>
              </div>
              <div className="text-right">
                <p className="text-lg font-semibold text-red-600">{formatTimeRemaining()}</p>
                <p className="text-sm text-gray-600">Time remaining</p>
              </div>
            </div>
            
            <Progress 
              value={((currentQuestion + 1) / questions.length) * 100}
              className="h-2 mb-8"
            />
            
            {/* Question card */}
            <Card className="mb-6">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-6">
                  {currentQuestion + 1}. {questions[currentQuestion].question}
                </h2>
                
                <div className="space-y-3">
                  {questions[currentQuestion].options.map((option, optionIndex) => (
                    <div
                      key={optionIndex}
                      className={`p-4 border rounded-lg cursor-pointer transition-all ${
                        selectedAnswers[currentQuestion] === optionIndex
                          ? 'border-brand-blue bg-brand-blue bg-opacity-5'
                          : 'hover:border-gray-400'
                      }`}
                      onClick={() => handleSelectAnswer(currentQuestion, optionIndex)}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center border ${
                            selectedAnswers[currentQuestion] === optionIndex
                              ? 'border-brand-blue bg-brand-blue text-white'
                              : 'border-gray-300'
                          }`}
                        >
                          {String.fromCharCode(65 + optionIndex)}
                        </div>
                        <span>{option}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="p-6 pt-0 flex justify-between">
                <Button
                  variant="outline"
                  onClick={goToPreviousQuestion}
                  disabled={currentQuestion === 0}
                >
                  Previous
                </Button>
                
                {currentQuestion < questions.length - 1 ? (
                  <Button
                    onClick={goToNextQuestion}
                    disabled={selectedAnswers[currentQuestion] === undefined}
                  >
                    Next
                  </Button>
                ) : (
                  <Button
                    onClick={handleSubmitTest}
                    disabled={selectedAnswers.length !== questions.length || selectedAnswers.some(a => a === undefined)}
                  >
                    Submit Test
                  </Button>
                )}
              </CardFooter>
            </Card>
            
            {/* Question navigator */}
            <div className="bg-white p-4 rounded-lg shadow">
              <p className="text-sm font-medium mb-3">Question Navigator:</p>
              <div className="flex flex-wrap gap-2">
                {questions.map((_, index) => (
                  <button
                    key={index}
                    className={`w-8 h-8 rounded-full text-sm flex items-center justify-center transition-colors ${
                      index === currentQuestion
                        ? 'bg-brand-blue text-white'
                        : selectedAnswers[index] !== undefined
                        ? 'bg-brand-blue bg-opacity-10 text-brand-blue'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                    onClick={() => setCurrentQuestion(index)}
                  >
                    {index + 1}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default DomainTest;
