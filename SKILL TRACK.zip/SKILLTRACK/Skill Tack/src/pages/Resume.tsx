
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppSidebar } from '@/components/AppSidebar';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { CircleCheck, CircleX, Circle, Upload, FileText, AlertCircle, ThumbsUp } from 'lucide-react';
import { getCurrentUser, saveResumeAnalysis } from '@/lib/storage';
import AnimatedSection from '@/components/AnimatedSection';
import { toast } from 'sonner';

interface AnalysisResult {
  score: number;
  suggestions: string[];
  keywords: {
    present: string[];
    missing: string[];
  };
  formatting: {
    good: string[];
    improvement: string[];
  };
}

const Resume = () => {
  const navigate = useNavigate();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [userDomain, setUserDomain] = useState<string | null>(null);

  useEffect(() => {
    const user = getCurrentUser();
    if (!user) {
      toast.error('Please sign in to use the resume analyzer');
      navigate('/');
      return;
    }

    if (user.selectedDomain) {
      setUserDomain(user.selectedDomain);
    }

    // Check if user already has a resume analysis
    if (user.resumeAnalysis) {
      setAnalysisResult({
        score: user.resumeAnalysis.score,
        suggestions: user.resumeAnalysis.suggestions,
        keywords: {
          present: ['React', 'JavaScript', 'TypeScript', 'HTML', 'CSS', 'Tailwind'],
          missing: ['Redux', 'Next.js', 'GraphQL', 'Responsive Design'],
        },
        formatting: {
          good: ['Clear section headers', 'Proper contact information', 'Bullet points for clarity'],
          improvement: ['Too lengthy - consider one page maximum', 'Use action verbs to start bullet points'],
        }
      });
    }
  }, [navigate]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      // Check if file is PDF or text file
      if (file.type === 'application/pdf' || file.type === 'text/plain') {
        setSelectedFile(file);
        setFileName(file.name);
      } else {
        toast.error('Please upload a PDF or text file');
        e.target.value = '';
      }
    }
  };

  const handleAnalyzeResume = () => {
    if (!selectedFile) {
      toast.error('Please upload a resume file first');
      return;
    }

    setIsAnalyzing(true);

    // Simulate analysis delay
    setTimeout(() => {
      // Generate fake analysis result
      const result: AnalysisResult = {
        score: Math.floor(Math.random() * 41) + 60, // Score between 60-100
        suggestions: [
          'Add more specific achievements with metrics',
          'Include relevant certifications',
          'Tailor your resume more specifically to the job description',
          'Use more industry-specific keywords',
          'Consider a more modern resume design',
          'Limit resume to one page for better readability'
        ],
        keywords: {
          present: ['React', 'JavaScript', 'TypeScript', 'HTML', 'CSS', 'Tailwind'],
          missing: ['Redux', 'Next.js', 'GraphQL', 'Responsive Design'],
        },
        formatting: {
          good: ['Clear section headers', 'Proper contact information', 'Bullet points for clarity'],
          improvement: ['Too lengthy - consider one page maximum', 'Use action verbs to start bullet points'],
        }
      };

      setAnalysisResult(result);
      setIsAnalyzing(false);

      // Save to localStorage
      saveResumeAnalysis(result.score, result.suggestions);
      toast.success('Resume analysis completed');
    }, 2000);
  };

  return (
    <div className="flex min-h-screen bg-background">
      <AppSidebar />
      <div className="flex-1 p-8 pt-6 sm:ml-64">
        <div className="max-w-5xl mx-auto">
          <AnimatedSection>
            <h1 className="text-3xl font-bold tracking-tight mb-2">Resume Analyzer</h1>
            <p className="text-muted-foreground mb-8">
              Upload your resume to get AI-powered feedback and suggestions specifically for {userDomain || 'your domain'}.
            </p>
          </AnimatedSection>

          <div className="grid gap-8 md:grid-cols-2">
            {/* Upload Section */}
            <AnimatedSection delay={100}>
              <Card>
                <CardHeader>
                  <CardTitle>Upload Your Resume</CardTitle>
                  <CardDescription>
                    Upload a PDF or text file of your resume to analyze
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div 
                    className={`border-2 border-dashed rounded-lg p-8 text-center mb-6 ${
                      selectedFile ? 'border-green-500 bg-green-50' : 'border-gray-300'
                    }`}
                  >
                    <input
                      type="file"
                      id="resume-upload"
                      accept=".pdf,.txt"
                      onChange={handleFileChange}
                      className="hidden"
                      disabled={isAnalyzing}
                    />
                    <label
                      htmlFor="resume-upload"
                      className="flex flex-col items-center justify-center cursor-pointer"
                    >
                      {selectedFile ? (
                        <>
                          <FileText className="h-12 w-12 text-green-500 mb-4" />
                          <p className="text-lg font-medium text-green-700">{fileName}</p>
                          <p className="text-sm text-muted-foreground mt-1">Click to change file</p>
                        </>
                      ) : (
                        <>
                          <Upload className="h-12 w-12 text-gray-400 mb-4" />
                          <p className="text-lg font-medium">Drag & drop or click to upload</p>
                          <p className="text-sm text-muted-foreground mt-1">Supports PDF, TXT (Max 5MB)</p>
                        </>
                      )}
                    </label>
                  </div>

                  <Button 
                    onClick={handleAnalyzeResume} 
                    disabled={!selectedFile || isAnalyzing}
                    className="w-full"
                  >
                    {isAnalyzing ? 'Analyzing...' : 'Analyze Resume'}
                  </Button>
                </CardContent>
              </Card>
            </AnimatedSection>

            {/* ATS Info Section */}
            <AnimatedSection delay={200}>
              <Card>
                <CardHeader>
                  <CardTitle>About ATS Systems</CardTitle>
                  <CardDescription>
                    How Applicant Tracking Systems evaluate your resume
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 text-sm">
                    <p>
                      <strong>Applicant Tracking Systems (ATS)</strong> are software applications that 
                      employers use to manage job applications and screen candidates.
                    </p>
                    <p>
                      <strong>How ATS Works:</strong>
                    </p>
                    <ul className="space-y-2">
                      <li className="flex gap-2">
                        <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0" />
                        <span>Scans resumes for keywords relevant to the job position</span>
                      </li>
                      <li className="flex gap-2">
                        <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0" />
                        <span>Ranks candidates based on keyword matches and qualifications</span>
                      </li>
                      <li className="flex gap-2">
                        <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0" />
                        <span>Filters out resumes that don't meet minimum requirements</span>
                      </li>
                      <li className="flex gap-2">
                        <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0" />
                        <span>May struggle with complex layouts, graphics, or uncommon file formats</span>
                      </li>
                    </ul>
                    
                    <p className="mt-4">
                      <strong>Tips for ATS Optimization:</strong>
                    </p>
                    <ul className="space-y-2">
                      <li className="flex gap-2">
                        <ThumbsUp className="h-5 w-5 text-green-500 flex-shrink-0" />
                        <span>Use standard section headings (Education, Experience, Skills)</span>
                      </li>
                      <li className="flex gap-2">
                        <ThumbsUp className="h-5 w-5 text-green-500 flex-shrink-0" />
                        <span>Include keywords from the job description</span>
                      </li>
                      <li className="flex gap-2">
                        <ThumbsUp className="h-5 w-5 text-green-500 flex-shrink-0" />
                        <span>Use a simple, clean format without tables or columns</span>
                      </li>
                      <li className="flex gap-2">
                        <ThumbsUp className="h-5 w-5 text-green-500 flex-shrink-0" />
                        <span>Save as PDF or .docx for best compatibility</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </AnimatedSection>
          </div>

          {/* Analysis Results */}
          {analysisResult && (
            <AnimatedSection delay={300} className="mt-8">
              <Card>
                <CardHeader>
                  <CardTitle>Analysis Results</CardTitle>
                  <CardDescription>
                    Based on ATS optimization and industry best practices
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-8">
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">ATS Compatibility Score</span>
                      <span className="font-medium">{analysisResult.score}%</span>
                    </div>
                    <Progress value={analysisResult.score} className="h-2" />
                    <div className="mt-1 text-sm text-muted-foreground text-right">
                      {analysisResult.score >= 80 
                        ? 'Excellent! Your resume is well-optimized for ATS systems.' 
                        : analysisResult.score >= 60 
                          ? 'Good, but there\'s room for improvement.'
                          : 'Needs significant improvements to pass ATS filters.'}
                    </div>
                  </div>

                  <Tabs defaultValue="suggestions">
                    <TabsList className="grid grid-cols-3 mb-4">
                      <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
                      <TabsTrigger value="keywords">Keywords</TabsTrigger>
                      <TabsTrigger value="formatting">Formatting</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="suggestions">
                      <ul className="space-y-2">
                        {analysisResult.suggestions.map((suggestion, index) => (
                          <li key={index} className="flex gap-2 items-start">
                            <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                            <span>{suggestion}</span>
                          </li>
                        ))}
                      </ul>
                    </TabsContent>
                    
                    <TabsContent value="keywords">
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium mb-2">Keywords Found</h3>
                          <ul className="space-y-2">
                            {analysisResult.keywords.present.map((keyword, index) => (
                              <li key={index} className="flex gap-2 items-center">
                                <CircleCheck className="h-5 w-5 text-green-500" />
                                <span>{keyword}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <h3 className="font-medium mb-2">Recommended Keywords to Add</h3>
                          <ul className="space-y-2">
                            {analysisResult.keywords.missing.map((keyword, index) => (
                              <li key={index} className="flex gap-2 items-center">
                                <CircleX className="h-5 w-5 text-red-500" />
                                <span>{keyword}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="formatting">
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium mb-2">Good Formatting</h3>
                          <ul className="space-y-2">
                            {analysisResult.formatting.good.map((item, index) => (
                              <li key={index} className="flex gap-2 items-center">
                                <CircleCheck className="h-5 w-5 text-green-500" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <h3 className="font-medium mb-2">Areas for Improvement</h3>
                          <ul className="space-y-2">
                            {analysisResult.formatting.improvement.map((item, index) => (
                              <li key={index} className="flex gap-2 items-center">
                                <Circle className="h-5 w-5 text-amber-500" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </AnimatedSection>
          )}
        </div>
      </div>
    </div>
  );
};

export default Resume;
